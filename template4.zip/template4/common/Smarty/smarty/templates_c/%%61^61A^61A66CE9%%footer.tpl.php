<?php /* Smarty version 2.6.7, created on 2005-11-11 18:31:39
         compiled from simpleGreen/footer.tpl */ ?>
	<table border=0 cellspacing=0 cellpadding=0>
    <TR>
		<TD>
			<IMG SRC="<?php echo $this->_tpl_vars['RELA_DIR']; ?>
/themes/<?php echo $this->_tpl_vars['CURRENT_THEME']; ?>
/images/design2_37.gif" WIDTH=7 HEIGHT=17 ALT=""></TD>
		<TD>
			<IMG SRC="<?php echo $this->_tpl_vars['RELA_DIR']; ?>
/themes/<?php echo $this->_tpl_vars['CURRENT_THEME']; ?>
/images/design2_38.gif" WIDTH=177 HEIGHT=17 ALT=""></TD>
		<TD class="green2">&nbsp;			</TD>
	    <TD><img src="<?php echo $this->_tpl_vars['RELA_DIR']; ?>
/themes/<?php echo $this->_tpl_vars['CURRENT_THEME']; ?>
/images/rightbottom.gif" alt="" width="7" height="17"></TD>
	</TR>
	<TR>
				<TD>&nbsp;			</TD>
		<TD colspan="3" align="right" class="footerStyle"><?php echo $this->_tpl_vars['copyright']; ?>
</TD>
	</TR>
    <TR><TD colspan="4">&nbsp;			</TD></TR>
    </table>