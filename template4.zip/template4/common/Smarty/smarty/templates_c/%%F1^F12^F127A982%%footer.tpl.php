<?php /* Smarty version 2.6.7, created on 2005-06-26 13:18:49
         compiled from default2/footer.tpl */ ?>
<table width="100%" cellspacing="0" cellpadding="0" border="0">
	<tr>
		<td class=footer><?php echo $this->_tpl_vars['copyright']; ?>
 </td>
	</tr>
	
</table>