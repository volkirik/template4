<?php /* Smarty version 2.6.7, created on 2005-11-17 23:47:22
         compiled from simpleGreen/admin.domainsync.result.tpl */ ?>
                  <br>
<table width="95%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr> 
    <td align=center>
	    <?php echo $this->_tpl_vars['update_result']; ?>

	</td>
  </tr>
</table>
                  <p>&nbsp;</p>