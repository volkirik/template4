<?php /* Smarty version 2.6.7, created on 2005-11-16 18:57:27
         compiled from simpleGreen/domain.whois.result.tpl */ ?>
<table width="95%" border="0" cellspacing="0" cellpadding="0" align="center">
 <tr> 
    <td>
	  <pre><?php echo $this->_tpl_vars['whois_result']; ?>
</pre>
    </td>
  </tr>
</table>