<?php /* Smarty version 2.6.7, created on 2005-09-07 12:55:09
         compiled from default/footer.tpl */ ?>
<table width="100%" cellspacing="0" cellpadding="0" border="0">
	<tr>
		<td class=footer><?php echo $this->_tpl_vars['copyright']; ?>
 </td>
	</tr>
	
</table>