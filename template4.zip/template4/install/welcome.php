<html>
<head>
<title>OnlineNIC Template 4.0 Install Wizard</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<!-- 
<style>
	body, td, tr, table, p {font-family:Verdana, Arial}
</style>
-->
<link type="text/css"  href="../themes/default/style.css" rel="StyleSheet">
</head>

<body bgcolor="#FFFFFF" text="#000000" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table width="100%" border="0" cellspacing="0" cellpadding="0" height="100%">
  <tr> 
    <td colspan="2" height="9"> 
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr bgcolor="#0B79B5"> 
          <td height="50" width="1%" bgcolor="#0B79B5">&nbsp;</td>
          <td height="50" width="33%" bgcolor="#0B79B5"><img src="images/title.jpg" width="217" height="51"></td>
          <td height="50" width="45%" bgcolor="#0B79B5">&nbsp;</td>
          <td height="50" width="21%" bgcolor="#0B79B5">&nbsp;</td>
        </tr>
      </table>
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td height="5
	" bgcolor="#FFCC00"></td>
        </tr>
      </table>
</td>
  </tr>
  <tr> 
    <td width="20%" bgcolor="#98BCED" valign="top"> 
      <p>&nbsp;</p>
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td height="22" width="8%" bgcolor="#FFFFFF"><font color="#FFCC00"></font></td>
          <td height="22" width="92%" bgcolor="#FFFFFF"><b><font color="#EDB903">Start</font></b></td>
        </tr>
        <tr> 
          <td height="22" width="8%">&nbsp;</td>
          <td height="22" width="92%"><b><font color="#FFFFFF">Database Setting</font></b></td>
        </tr>
        <tr> 
          <td height="22" width="8%">&nbsp;</td>
          <td height="22" width="92%"><b><font color="#FFFFFF">Data Initialization</font></b></td>
        </tr>
        <tr> 
          <td height="22" width="8%">&nbsp;</td>
          <td height="22" width="92%"><b><font color="#FFFFFF">End</font></b></td>
        </tr>
        <tr> 
          <td height="22" width="8%">&nbsp;</td>
          <td height="22" width="92%">&nbsp;</td>
        </tr>
        <tr> 
          <td height="22" width="8%">&nbsp;</td>
          <td height="22" width="92%">&nbsp;</td>
        </tr>
        <tr> 
          <td height="22" width="8%">&nbsp;</td>
          <td height="22" width="92%">&nbsp;</td>
        </tr>
        <tr>
          <td height="22" width="8%">&nbsp;</td>
          <td height="22" width="92%"><b><a href="../help/installation.html" target="_blank"><font color="#FFFFFF">Install 
            Help</font></a></b></td>
        </tr>
      </table>
      <p>&nbsp;</p>
    </td>
    <td width="80%" valign="top"> <br>
      <table width="90%" border="0" cellspacing="0" cellpadding="0" align="center">
        <tr> 
          <td> 
            <blockquote> 
              <p align="center"><font size="4" face="Arial, Helvetica, sans-serif"><b><font color="#DFB300">OnlineNIC's 
                Reseller Template System (Version 4.0)</font></b></font></p>
            </blockquote>
            <p><b><font size="2">System Requirements</font></b><font size="2"><br>
              Operation system:Linux<br>
              Web server:Any webserver with PHP support.<br>
              Database:MySQL<br>
              <br>
              <b>System Intruction</b><br>
              OnlineNIC's reseller template system allows OnlineNIC resellers 
              to offer real-time domain registration services directly to their 
              customers on their own web site, with their own branding. The template 
              system connects transparently to OnlineNIC's real-time registration 
              server on the back end. The OnlineNIC reseller template system is 
              easy to implement and requires little programming.<br>
              <br></font></p>
            <blockquote>
              <p align="center">
              <div align="center">
                <input type="button" onClick="document.location='<?php echo $_SERVER["PHP_SELF"] ?>?action=step1'" value="Install now">
	     </div>
            </blockquote>
          </td>
        </tr>
      </table>
    </td>
  </tr>
</table>
</body>
</html>
