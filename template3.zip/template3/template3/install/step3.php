<html>
<head>
<title>OnlineNIC Template 3.0 Install Wizard</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style>
	body, td, tr, table, p {font-family:Verdana, Arial}
</style>
</head>

<body bgcolor="#FFFFFF" text="#000000" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table width="100%" border="0" cellspacing="0" cellpadding="0" height="100%">
  <tr> 
    <td colspan="2" height="9"> 
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr bgcolor="#0B79B5"> 
          <td height="50" width="1%" bgcolor="#0B79B5">&nbsp;</td>
          <td height="50" width="33%" bgcolor="#0B79B5"><img src="images/title.jpg" width="217" height="51"></td>
          <td height="50" width="45%" bgcolor="#0B79B5">&nbsp;</td>
          <td height="50" width="21%" bgcolor="#0B79B5">&nbsp;</td>
        </tr>
      </table>
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td height="5
	" bgcolor="#FFCC00"></td>
        </tr>
      </table>
</td>
  </tr>
  <tr> 
    <td width="20%" bgcolor="#98BCED" valign="top"> 
      <p>&nbsp;</p>
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td height="22" width="8%"><font color="#FFCC00"></font></td>
          <td height="22" width="92%"><b><font color="#FFFFFF">Start</font></b></td>
        </tr>
        <tr> 
          <td height="22" width="8%">&nbsp;</td>
          <td height="22" width="92%"><b><font color="#FFFFFF">Database Setting</font></b></td>
        </tr>
        <tr> 
          <td height="22" width="8%">&nbsp;</td>
          <td height="22" width="92%"><b><font color="#FFFFFF">Data Initialization</font></b></td>
        </tr>
        <tr> 
          <td height="22" width="8%" bgcolor="#FFFFFF">&nbsp;</td>
          <td height="22" width="92%" bgcolor="#FFFFFF"><b><font color="#EDB903">End</font></b></td>
        </tr>
        <tr> 
          <td height="22" width="8%">&nbsp;</td>
          <td height="22" width="92%">&nbsp;</td>
        </tr>
        <tr> 
          <td height="22" width="8%">&nbsp;</td>
          <td height="22" width="92%">&nbsp;</td>
        </tr>
        <tr> 
          <td height="22" width="8%">&nbsp;</td>
          <td height="22" width="92%">&nbsp;</td>
        </tr>
        <tr>
          <td height="22" width="8%">&nbsp;</td>
          <td height="22" width="92%"><b><a href="../help/installation.html" target="_blank"><font color="#FFFFFF">Install 
            Help</font></a></b></td>
        </tr>
      </table>
      <p>&nbsp;</p>
    </td>
    <td width="80%" valign="top"> <br>
      <table width="90%" border="0" cellspacing="0" cellpadding="0" align="center">
        <tr> 
          <td valign="top" align="center"> 
            <p align="center"><font size="4" face="Arial, Helvetica, sans-serif"><b><font color="#DFB300">OnlineNIC's 
              Reseller Template System (Version 3.0)</font></b></font></p>
              
            <p>&nbsp;</p>
            <p><font color="#0B79B5"><b>The Template 3.0 has been Installed successfully</b></font></p>
            <p>&nbsp;</p>
            <table width="50%" border="0" cellspacing="1" cellpadding="2" bgcolor="#000000">
              <tr> 
                <td height="22" bgcolor="#FFCC00" align="center" width="52%">Sup-Administrator ID</td>
                <td height="22" bgcolor="#FFFDE8" width="48%">100</td>
              </tr>
              <tr> 
                <td height="22" bgcolor="#FFCC00" align="center" width="52%">Super-Administrator Password </td>
                <td height="22" bgcolor="#FFFDE8" width="48%"><?php echo $admin_password1 ?></td>
              </tr>
            </table>
            <p>&nbsp;</p>
            <p>Click <a href="../member/myaccount.php">here</a> to login admin page</p>
            <p>&nbsp;</p>
	      </td>
        </tr>
      </table>
    </td>
  </tr>
</table>
</body>
</html>
