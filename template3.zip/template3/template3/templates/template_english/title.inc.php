<?php
global $member_info;
?>
<html>
<head>
<title><?php echo TITLE ?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="<?php echo RELA_DIR ?>templates/<?php echo CURRENT_SKIN ?>/css/style.css">
</head>

<body bgcolor="#EFEFEF" text="#000000" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table width="750" border="0" align="center" cellspacing="0" cellpadding="0">
  <tr>
    <td colspan="3"><img src="<?php echo RELA_DIR ?>templates/<?php echo CURRENT_SKIN ?>/images/spot.gif" width="1" height="5"></td>
  </tr>
  <tr> 
    <td colspan="3" bgcolor="#000000"><img src="<?php echo RELA_DIR ?>templates/<?php echo CURRENT_SKIN ?>/images/black.gif" width="1" height="1"></td>
  </tr>
  <tr> 
    <td width="1" bgcolor="#000000"><img src="<?php echo RELA_DIR ?>templates/<?php echo CURRENT_SKIN ?>/images/black.gif" width="1" height="1"></td>
    <td width="748" bgcolor="#FFFFFF">
      <table width="748" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td height="40" bgcolor="#FFFFFF" width="150" align="center" colspan="2"><img src="<?php echo RELA_DIR ?>templates/<?php echo CURRENT_SKIN ?>/images/onlinenic.gif" width="135" height="23"></td>
          <td height="40" bgcolor="#98BCED" width="598" colspan="2">&nbsp;</td>
        </tr>
        <tr> 
          <td width="150" height="10" bgcolor="#1F5CAF" colspan="2"><img src="/templates/<?php echo CURRENT_SKIN ?>/images/arrow.gif" width="13" height="9"></td>
          <td width="598" height="20" colspan="2" bgcolor="#1F5CAF"> 
            <table width="100%" border="0" cellspacing="0" cellpadding="0">
              <tr align="center"> 
                <td width="14%"><font color="#FFFFFF"></font></td>
                <td width="14%">&nbsp;</td>
                <td width="14%">&nbsp;</td>
                <td width="14%">&nbsp;</td>
                <td width="14%"><b><a href="<?php echo RELA_DIR ?>" class="menu1">Home</a></b></td>
                <td width="14%"><b><a href="<?php echo RELA_DIR ?>member/myaccount.php" class="menu1">My Account</a></b></td>
                <td width="14%"><b><a href="<?php echo RELA_DIR ?>member/logout.php" class="menu1">Logout</a></b></td>
              </tr>
            </table>
          </td>
        </tr>
        <tr> 
      <td width="3" bgcolor="#1F5CAF"><img src="<?php echo RELA_DIR ?>templates/<?php echo CURRENT_SKIN ?>/images/spot.gif"></td>
      <td valign="top" bgcolor="#FFFEF7"> 
        <table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr> 
            <td width="100%"> 
              <table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
                <tr> 
                  <td bgcolor="#FFCC00" height="3" width="25%"><img src="<?php echo RELA_DIR ?>templates/<?php echo CURRENT_SKIN ?>/images/spot.gif"></td>
                  <td bgcolor="#FFE98E" height="3" width="25%"><img src="<?php echo RELA_DIR ?>templates/<?php echo CURRENT_SKIN ?>/images/spot.gif"></td>
                  <td bgcolor="#FFF3C4" height="3" width="25%"><img src="<?php echo RELA_DIR ?>templates/<?php echo CURRENT_SKIN ?>/images/spot.gif"></td>
                  <td bgcolor="#FFFBE8" height="3" width="25%"><img src="<?php echo RELA_DIR ?>templates/<?php echo CURRENT_SKIN ?>/images/spot.gif"></td>
                </tr>
                <tr> 
                  <td colspan="4">
<?php
if(isset($member_info) && $member_info != -1)
{
?>
				  &nbsp;<b><font color="#1F5CAF">Business Tools</font></b></td>
                </tr>
                <tr> 
                  <td colspan="4"> 
                    <table width="80%" border="0" cellspacing="0" cellpadding="0" align="center">
                      <tr> 
                        <td><a href="<?php echo RELA_DIR ?>domain/whois.php" class="menu2">Whois 
                          Search </a> </td>
                      </tr>
                      <tr> 
                        <td><a href="<?php echo RELA_DIR ?>domain/registerdomain.php" class="menu2">Register Domain</a></td>
                      </tr>
                      <tr> 
                        <td><a href="<?php echo RELA_DIR ?>domain/domainmanage.php" class="menu2">Manage 
                          Domain </a></td>
                      </tr>
                    </table>
                  </td>
                </tr>
                <tr>
                  <td colspan="4">&nbsp;</td>
                </tr>
                <tr> 
                  <td colspan="4">&nbsp;<b><font color="#1F5CAF">Member Tools</font></b></td>
                </tr>
                <tr> 
                  <td colspan="4"> 
                    <table width="80%" border="0" cellspacing="0" cellpadding="0" align="center">
                      <tr> 
                        <td><a href="<?php echo RELA_DIR ?>member/updatecontact.php" class="menu2">Modify 
                          Account Info</a></td>
                      </tr>
                      <tr> 
                        <td><a href="<?php echo RELA_DIR ?>member/getpassword.php" class="menu2">Forgot 
                          Password</a></td>
                      </tr>
                      <tr> 
                        <td><a href="<?php echo RELA_DIR ?>member/orderlist.php" class="menu2">Transaction 
                          History</a></td>
                      </tr>
                    </table>
                  </td>
<?php
}else {
?>
                    <table width="80%" border="0" cellspacing="0" cellpadding="0" align="center">
                      <tr> 
                        <td height="23"><b><a href="<?php echo RELA_DIR ?>member/myaccount.php" class="menu2">Member 
                          Login</a> </b></td>
                      </tr>
                      <tr> 
                        <td height="23"><b><a href="<?php echo RELA_DIR ?>domain/whois.php" class="menu2">Whois 
                          Search </a></b></td>
                      </tr>
                      <tr> 
                        <td height="23"><b><a href="<?php echo RELA_DIR ?>member/signup.php" class="menu2">Sign 
                          Up </a></b></td>
                      </tr>
                      <tr> 
                        <td height="23"><b><a href="<?php echo RELA_DIR ?>member/getpassword.php" class="menu2">Forgot 
                          Password </a></b></td>
                      </tr>
                    </table>
<?php
}
?>
                </tr>
                <tr> 
                  <td height="25" colspan="4">&nbsp;</td>
                </tr>
                <tr> 
                  <td colspan="4"><b></b></td>
                </tr>
              </table>
              </td>
          </tr>
        </table>
            
        <p>&nbsp;</p>
        <p>&nbsp;</p>
        <p>&nbsp;</p>
        <p>&nbsp;</p>
        <p>&nbsp;</p>
        <p>&nbsp;</p>
      </td>
          <td width="1" background="<?php echo RELA_DIR ?>templates/<?php echo CURRENT_SKIN ?>/images/line_1.gif" valign="top"><img src="<?php echo RELA_DIR ?>templates/<?php echo CURRENT_SKIN ?>/images/line_1.gif" width="1" height="4"></td>
          <td width="597" valign="top"> 
            <table width="100%" border="0" cellspacing="0" cellpadding="0">
              <tr> 
                <td align="right"><img src="<?php echo RELA_DIR ?>templates/<?php echo CURRENT_SKIN ?>/images/line_2.gif" width="222" height="6"></td>
              </tr>
            </table>
            <table width="95%" border="0" cellspacing="0" cellpadding="0" align="center">
              <tr>
                <td>