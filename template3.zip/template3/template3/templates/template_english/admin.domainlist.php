<?php
showTitle("Domain list");
?>
<script language="javascript">
	function renewDomain(myForm)
	{
		myYear = prompt("For how many years would you like to renew this domain?", '1');
		myForm.year.value = myYear;
		myForm.action.value = "renewDomain";
		myForm.submit();
	}
	function deleteDomain(myForm)
	{
		myForm.action.value = "deleteDomain";
		myForm.submit();
	}
</script>
                  <br>
<?php
showTip("Wecolme to Manage Domain Area! You may adopt this tool to implement domain management, including domain renewal & deletion, domain information modification and nameserver change.");
?>
<table width="95%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr>
    <td> <b><br>
      </b> <br>
      <form action="<?php echo $_SERVER["PHP_SELF"] ?>" method="post" style="margin:0px">
        <table width="100%" border="0" cellspacing="0" cellpadding="0" align="center" bgcolor="#E1ECFB" class="border1">
          <tr>
            <td>
              <table width="90%" border="0" cellspacing="0" cellpadding="0" align="center">
                <tr> 
                  <td> Time: 
                    <select name="startYear">
                      <option>Year</option>
                      <?php
for($i_year = 2002; $i_year < 2006; $i_year ++)
{
	if($startYear == $i_year)
	{
		echo "<option value=" . $i_year . " selected>" . $i_year;
	}else {
		echo "<option value=" . $i_year . ">" . $i_year;
	}
}
?>
                    </select>
                    <select name="startMonth">
                      <option>Mon</option>
                      <?php
for($i_month = 1; $i_month < 13; $i_month ++)
{
	if($startMonth == $i_month)
	{
		echo "<option value=" . $i_month . " selected>" . $i_month;
	}else {
		echo "<option value=" . $i_month . ">" . $i_month;
	}
}
?>
                    </select>
                    <select name="startDay">
                      <option>Day</option>
                      <?php
for($i_day = 1; $i_day < 32; $i_day ++)
{
	if($startDay == $i_day)
	{
		echo "<option value=" . $i_day . " selected>" . $i_day;
	}else {
		echo "<option value=" . $i_day . ">" . $i_day;
	}
}
?>
                    </select>
                    to 
                    <select name="toYear">
                      <option>Year</option>
                      <?php
for($i_year = 2002; $i_year < 2006; $i_year ++)
{
	if($toYear == $i_year)
	{
		echo "<option value=" . $i_year . " selected>" . $i_year;
	}else {
		echo "<option value=" . $i_year . ">" . $i_year;
	}
}
?>
                    </select>
                    <select name="toMonth">
                      <option>Mon</option>
                      <?php
for($i_month = 1; $i_month < 13; $i_month ++)
{
	if($toMonth == $i_month)
	{
		echo "<option value=" . $i_month . " selected>" . $i_month;
	}else {
		echo "<option value=" . $i_month . ">" . $i_month;
	}
}
?>
                    </select>
                    <select name="toDay">
                      <option>Day</option>
                      <?php
for($i_day = 1; $i_day < 32; $i_day ++)
{
	if($toDay == $i_day)
	{
		echo "<option value=" . $i_day . " selected>" . $i_day;
	}else {
		echo "<option value=" . $i_day . ">" . $i_day;
	}
}
?>
                    </select>
                  </td>
                </tr>
              </table>
              <br>
              <table width="90%" border="0" cellspacing="0" cellpadding="0" align="center">
                <tr> 
                  <td width="7%">Type: </td>
                  <td width="12%"> 
                    <select name="product_id">
                      <option>All</option>
                      <?php
while(!$rs2->EOF)
{
	if($rs2->fields[1] == $product_id)
	{
		echo "<option value=\"" . $rs2->fields[1] . "\" selected>" . $rs2->fields[3];
	}else {
		echo "<option value=\"" . $rs2->fields[1] . "\">" . $rs2->fields[3];
	}
	$rs2->MoveNext();
}
?>
                    </select>
                  </td>
                  <td width="7%">Member:</td>
                  <td width="10%"> 
                    <input type="text" name="member_name" size="10" value="<?php echo $member_name ?>">
                  </td>
                  <td width="10%">Domain:</td>
                  <td width="7%"> 
                    <input type="text" name="domain_name" size="10" value="<?php echo $domain_name ?>">
                  </td>
                  <td width="47%"> 
                    <input type="submit" name="Submit" value="Query">
                  </td>
                </tr>
              </table>
            </td>
          </tr>
        </table>
        <br>
        <br>
      </form>
      <form method="post" action="<?php echo $_SERVER["PHP_SELF"] ?>" name="domainManage" style="margin:0px">
        <table width="100%" border="0" cellspacing="1" cellpadding="2" align="center">
          <tr bgcolor="#999999"> 
            <td width="4%" height="20"><b><font color="#FFFFFF">&nbsp;</font></b></td>
            <td width="26%" height="20"><b><font color="#FFFFFF">Domain</font></b></td>
            <td width="20%" height="20"><b><font color="#FFFFFF">Dns1</font></b></td>
            <td width="20%" height="20"><b><font color="#FFFFFF">Dns2</font></b></td>
            <td width="20%" height="20"><b><font color="#FFFFFF">Registration 
              Date </font></b></td>
            <td width="16%" height="20"><b><font color="#FFFFFF">Year</font></b></td>
          </tr>
          <?php
if(!$rs->EOF)
{
	$rs->Move(($currentPage - 1) * PAGE_SIZE);
	$i = 0;
	while(!$rs->EOF && $i < PAGE_SIZE)
	{
		if($i % 2)
		{
			$color = " bgcolor=\"#EFEFEF\"";
		}else {
			$color = "";
		}
?>
          <tr> 
            <td height="20" class="p8"<?php echo $color ?> width="4%"> 
              <input type="radio" name="domain_id" value="<?php echo $rs->fields[0] ?>">
            </td>
            <td height="20" class="p8"<?php echo $color ?> width="27%"> <a href="<?php echo $_SERVER["PHP_SELF"] ?>?action=showContact&domain_id=<?php echo $rs->fields[0] ?>" class="menu2"> 
              <?php echo $rs->fields[1] . " (" . $rs->fields[8] . ")" ?>
              </a> </td>
            <td height="20" class="p8"<?php echo $color ?> width="15%"> <a href="<?php echo $_SERVER["PHP_SELF"] ?>?action=showNS&domain_id=<?php echo $rs->fields[0] ?>" class="menu2"> 
              <?php echo $rs->fields[6] ?>
              </a> </td>
            <td height="20" class="p8"<?php echo $color ?> width="17%"> 
              <?php echo $rs->fields[7] ?>
            </td>
            <td height="20" class="p8"<?php echo $color ?> width="25%"> 
              <?php echo $rs->fields[4] ?>
            </td>
            <td height="20" class="p8"<?php echo $color ?> width="16%"> 
              <?php echo $rs->fields[5] ?>
            </td>
          </tr>
          <?php
		$i ++;
		$rs->MoveNext();
	}
?>
          <tr bgcolor="#CCCCCC"> 
            <td height="20" colspan="6"> 
              <?php
	$webaddress = $_SERVER["PHP_SELF"] . "?startYear=" . $startYear . "&startMonth=" . $startMonth . "&startDay=" . $startDay . "&toYear=" . $toYear . "&toMonth=" . $toMonth . "&toDay=" . $toDay . "&domain_name=" . $domain_name . "&member_name=" . $member_name;
	showPageButton($currentPage, $pageCount, $totalRecord, $webaddress)
?>
            </td>
          </tr>
          <tr align="center"> 
            <td height="20" colspan="6"> 
              <p>&nbsp;</p>
              <p> 
                <input type="button" name="renew" value="Renew domain" onClick = "renewDomain(this.form);">
                <input type="button" name="delete" value="Delete domain" onClick = "deleteDomain(this.form);">
              </p>
            </td>
          </tr>
          <?php
}
?>
        </table>
      <input type="hidden" name="transation" value="<?php echo $transation ?>">
	  <input type="hidden" name="action" value="">
	  <input type="hidden" name="year" value="">
      </form>
      
    </td>
  </tr>
</table>
                  <p>&nbsp;</p>