<?php
global	$member_name;
global	$member_password1;
global	$r_name;
global	$r_email;
showTitle("Sign Up");
?>
                  <br>
                  
<table width="95%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr> 
    <td > 
      <p><font color="#FF0000"><b><i><font size="3">Sign up successfully</font></i></b><br>
        <br>
        </font>Your username is: <?php echo $member_name ?><br>
        Your password is: <?php echo $member_password1 ?><br>
        <br>
        Please write these down in a safe place and please do not give your password to anyone.<br>
        <br>
        To continue using the system, please <a href="<?php echo RELA_DIR ?>member/login.php">login</a> 
        now. </p>
      </td>
  </tr>
</table>
                  <p>&nbsp;</p>