<?php
global $admin_info;
showTitle("Administrator List");
?>
<script language="javascript">
function doDelete()
{
	if(confirm("Are you sure to delete this Administrator?"))
	{
		return true;
	}
	else
	{
		return false;
	}
}
</script>
<br>
<table width="95%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr>
    <td>
      <form style="margin:0px">
        <table width="95%" border="0" cellspacing="1" cellpadding="0" align="center">
          <tr bgcolor="#999999"> 
            <td width="12%" height="20"><b><font color="#FFFFFF">&nbsp;Login ID</font></b></td>
            <td width="27%" height="20"><b><font color="#FFFFFF">&nbsp;Name</font></b></td>
            <td width="27%" height="20"><b><font color="#FFFFFF">&nbsp;Department</font></b></td>
            <td width="14%" height="20"><b><font color="#FFFFFF">&nbsp;Status</font></b></td>
            <td width="20%" height="20"><b><font color="#FFFFFF">&nbsp;Operation</font></b></td>
        </tr>
<?php
if(!$rs->EOF)
{
	$rs->Move(($currentPage - 1) * PAGE_SIZE);
	$i = 0;
	while(!$rs->EOF && $i < PAGE_SIZE)
	{
		if($i % 2)
		{
			$color = " bgcolor=\"#EFEFEF\"";
		}else {
			$color = "";
		}
?>
        <tr>
          <td height="20" class="p8"<?php echo $color ?>>
            &nbsp;<?php echo $rs->fields[0] ?>
          </td>
          <td height="20" class="p8"<?php echo $color ?>>
            &nbsp;<?php echo $rs->fields[1] ?>
          </td>
          <td height="20" class="p8"<?php echo $color ?>>
            &nbsp;<?php echo $rs->fields[2] ?>
          </td>
          <td height="20" class="p8"<?php echo $color ?>>
<?php
if($rs->fields[5] == 0)
	echo "&nbsp;<font color=\"#0000FF\">Start</font>";
else
	echo "&nbsp;<font color=\"#FF0000\">Stop</font>";
?>
          </td>
          <td height="20" class="p8"<?php echo $color ?>>
            <a href="<?php echo $_SERVER["PHP_SELF"] ?>?action=showModifyForm&currentPage=<?php echo $currentPage ?>&admin_id=<?php echo $rs->fields[0] ?>"><img src="<?php echo RELA_DIR ?>templates/<?php echo CURRENT_SKIN ?>/images/modify.gif" border="0" alt="Modify"></a>&nbsp;
            <a href="<?php echo $_SERVER["PHP_SELF"] ?>?action=deleteAdmin&currentPage=<?php echo $currentPage ?>&admin_id=<?php echo $rs->fields[0] ?>" onClick="return doDelete()"><img src="<?php echo RELA_DIR ?>templates/<?php echo CURRENT_SKIN ?>/images/delete.gif" border="0" alt="Delete"></a>&nbsp;
            <a href="<?php echo $_SERVER["PHP_SELF"] ?>?action=showSetTask&currentPage=<?php echo $currentPage ?>&admin_id=<?php echo $rs->fields[0] ?>"><img src="<?php echo RELA_DIR ?>templates/<?php echo CURRENT_SKIN ?>/images/lock.gif" border="0" alt="Access setting"></a>
          </td>
        </tr>
<?php
		$i ++;
		$rs->MoveNext();
	}
?>
        <tr> 
          <td height="20" bgcolor="#CCCCCC" colspan="5">
<?php
	$webaddress = $_SERVER["PHP_SELF"] . "?action=listAdmin";
	showPageButton($currentPage, $pageCount, $totalRecord, $webaddress)
?>
          </td>
        </tr>
<?php
}
?>
      </table>
      <table width="95%" border="0" cellspacing="1" cellpadding="0" align="center">
        <tr>
            <td align="center"><br>
      <input type="hidden" name="transation" value="<?php echo $transation ?>">
      <input type="button" name="new" value="New Admin" onClick="document.location.href='<?php echo $_SERVER["PHP_SELF"] ?>?action=showAddForm'">
            </td>
          </tr></table>
      </form>
      
    </td>
  </tr>
</table>
<p>&nbsp;</p>