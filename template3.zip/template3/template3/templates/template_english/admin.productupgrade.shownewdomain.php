<?php
global $admin_info;
showTitle("Domain upgrade");
?>
<br>
<?php
showTip("This section is used to add the new domain into your domain business scope. If you find any new domains below you are interested in, please feel free to choose them. ");
?>
<form action="<?php echo $_SERVER["PHP_SELF"] ?>" method="post">
  <table width="80%" border="0" cellspacing="0" cellpadding="0" align="center">
    <tr> 
      <td colspan="2" height="25">&nbsp; </td>
    </tr>
    <tr> 
      <td colspan="2" height="25"><b>New domain</b></td>
    </tr>
    <tr> 
      <td colspan="2" height="25"> 
        <table width="100%" border="0" cellspacing="0" cellpadding="0" class="border1">
<?php
$r_count = count($results);
if($r_count == 0)
{
?>
          <tr> 
            <td width="10%" height="25" align="center">&nbsp; 
              
            </td>
            <td width="90%" height="25">
              <font color="#FF0000">At present, there are no new domains for choosing.</font>
            </td>
          </tr>
<?php
}else {
	for($i = 0; $i < $r_count; $i ++)
	{
?>
          <tr> 
            <td width="10%" height="25" align="center"> 
              <input type="radio" name="product_id" value="<?php echo substr($results[$i], 0, 4) ?>">
            </td>
            <td width="90%" height="25">
              <?php echo substr($results[$i], 6) ?>
            </td>
          </tr>
<?php
	}
}
?>
        </table>
      </td>
    </tr>
    <tr> 
      <td width="30%" height="25">&nbsp;</td>
      <td width="70%" height="25">&nbsp;</td>
    </tr>
    <tr> 
      <td width="30%" height="25">&nbsp;</td>
      <td width="70%" height="25"> 
        <input type="submit" name="Submit" value="Domain upgrade">
        <input type="hidden" name="action" value="upgradeDomain">
      </td>
    </tr>
  </table>
</form>
<p>&nbsp;</p>