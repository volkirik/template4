<?php
global $admin_info;
showTitle("Administrator List &gt; Access Setting");
?>
<br>
<form action="<?php echo $_SERVER["PHP_SELF"] ?>" method="post">
  <table width="80%" border="0" cellspacing="0" cellpadding="0" align="center">
    <?php
if($message <> "")
{
?>
    <tr> 
      <td width="25%" height="25" colspan="2"> 
        <div style="border:solid 1px #FF0000;padding:5px"> <font class="p8"><b> 
          <?php echo $message ?>
          </b></font> </div>
      </td>
    </tr>
    <?php
}
?>
    <tr bgcolor="#EFEFEF"> 
      <td width="30%" height="25">&nbsp;<b>Name</b></td>
      <td width="70%" height="25" bgcolor="#EFEFEF"> 
        <?php echo $admin_name ?>
      </td>
    </tr>
    <tr bgcolor="#EFEFEF"> 
      <td width="30%" height="25">&nbsp;<b>Department</b></td>
      <td width="70%" height="25"> 
        <?php echo $admin_dept ?>
      </td>
    </tr>
    <tr bgcolor="#EFEFEF"> 
      <td height="25">&nbsp;<b>Add Time</b></td>
      <td height="25"> 
        <?php echo $add_time ?>
      </td>
    </tr>
    <tr> 
      <td colspan="2" height="25">&nbsp; </td>
    </tr>
    <tr> 
      <td colspan="2" height="25"><b>Admin Task</b></td>
    </tr>
    <tr> 
      <td colspan="2" height="25"> 
        <table width="100%" border="0" cellspacing="0" cellpadding="0" class="border1">
<?php
while(!$rs->EOF)
{
	$sql = "select * from admintask where admin_id=" . $admin_id . " and task_id=" . $rs->fields[0];
	$rs1 = $conn->Execute($sql);
	if(!$rs1)
	{
		showErrorMsg($conn->ErrorMsg());
	}
	if($rs1->RecordCount() == 1)
	{
		$check_status = " checked";
	}else {
		$check_status = "";
	}
?>
          <tr> 
            <td width="10%" height="25" align="center"> 
              <input type="checkbox" name="task_id[]" value="<?php echo $rs->fields[0] ?>"<?php echo $check_status ?>>
            </td>
            <td width="90%" height="25"><?php echo $rs->fields[1] ?></td>
          </tr>
<?php
	$rs->MoveNext();
}
?>
        </table>
      </td>
    </tr>
    <tr>
      <td width="30%" height="25">&nbsp;</td>
      <td width="70%" height="25">&nbsp;</td>
    </tr>
    <tr> 
      <td width="30%" height="25">&nbsp;</td>
      <td width="70%" height="25">
        <input type="submit" name="Submit" value="Set Admin Task">
        <input type="hidden" name="action" value="setAdminTask">
	<input type="hidden" name="admin_id" value="<?php echo $admin_id ?>">
	<input type="hidden" name="currentPage" value="<?php echo $_REQUEST["currentPage"] ?>">
      </td>
    </tr>
  </table>
</form>
<p>&nbsp;</p>