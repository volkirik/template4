<?php
global $admin_info;
showTitle("Member List");
?>
<script language="javascript">
function doDelete()
{
	if(confirm("Are you sure to delete this member?"))
	{
		return true;
	}
	else
	{
		return false;
	}
}
</script>
<br>
<form action="<?php echo $_SERVER["PHP_SELF"] ?>" method="post" style="margin:0px">
  <table width="90%" border="0" cellspacing="0" cellpadding="0" align="center" bgcolor="#E1ECFB" class="border1">
    <tr>
      <td> 
        <table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
          <tr> 
            <td> Sign-up date from 
              <select name="startYear">
                <option>Year</option>
                <?php
for($i_year = 2002; $i_year < 2006; $i_year ++)
{
	if($startYear == $i_year)
	{
		echo "<option value=" . $i_year . " selected>" . $i_year;
	}else {
		echo "<option value=" . $i_year . ">" . $i_year;
	}
}
?>
              </select>
              <select name="startMonth">
                <option>Mon</option>
                <?php
for($i_month = 1; $i_month < 13; $i_month ++)
{
	if($startMonth == $i_month)
	{
		echo "<option value=" . $i_month . " selected>" . $i_month;
	}else {
		echo "<option value=" . $i_month . ">" . $i_month;
	}
}
?>
              </select>
              <select name="startDay">
                <option>Day</option>
                <?php
for($i_day = 1; $i_day < 32; $i_day ++)
{
	if($startDay == $i_day)
	{
		echo "<option value=" . $i_day . " selected>" . $i_day;
	}else {
		echo "<option value=" . $i_day . ">" . $i_day;
	}
}
?>
              </select>
              to 
              <select name="toYear">
                <option>Year</option>
                <?php
for($i_year = 2002; $i_year < 2006; $i_year ++)
{
	if($toYear == $i_year)
	{
		echo "<option value=" . $i_year . " selected>" . $i_year;
	}else {
		echo "<option value=" . $i_year . ">" . $i_year;
	}
}
?>
              </select>
              <select name="toMonth">
                <option>Mon</option>
                <?php
for($i_month = 1; $i_month < 13; $i_month ++)
{
	if($toMonth == $i_month)
	{
		echo "<option value=" . $i_month . " selected>" . $i_month;
	}else {
		echo "<option value=" . $i_month . ">" . $i_month;
	}
}
?>
              </select>
              <select name="toDay">
                <option>Day</option>
                <?php
for($i_day = 1; $i_day < 32; $i_day ++)
{
	if($toDay == $i_day)
	{
		echo "<option value=" . $i_day . " selected>" . $i_day;
	}else {
		echo "<option value=" . $i_day . ">" . $i_day;
	}
}
?>
              </select>
            </td>
          </tr>
        </table>
        <br>
        <table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
          <tr> 
            <td width="21%">Ordered by:</td>
            <td width="10%"> 
              <select name="orders">
<?php
if($orders == 1)
{
?>
                <option value="1" selected>Member Level</option>
                <option value="2">Alphabetical Order</option>
                <option value="3">Sign-up Date</option>
<?php
}else if($orders == 2) {
?>
                <option value="1">Member Level</option>
                <option value="2" selected>Alphabetical Order</option>
                <option value="3">Sign-up Date</option>
<?php
}else if($orders == 3) {
?>
                <option value="1">Member Level</option>
                <option value="2">Alphabetical Order</option>
                <option value="3" selected>Sign-up Date</option>
<?php
}else {
?>
                <option value="1" selected>Member Level</option>
                <option value="2">Alphabetical Order</option>
                <option value="3">Sign-up Date</option>
<?php
}
?>
              </select>
            </td>
            <td width="20%">User name: </td>
            <td width="24%"> 
              <input type="text" name="member_name" size="10" value="<?php echo $member_name ?>">
            </td>
            <td width="25%"> 
              <input type="submit" name="Submit" value="Query">
            </td>
          </tr>
        </table>
      </td>
    </tr>
  </table>
</form>
<br>
<table width="90%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr>
    <td>
      <form style="margin:0px">
        <table width="100%" border="0" cellspacing="1" cellpadding="0" align="center">
          <tr bgcolor="#999999"> 
            <td width="12%" height="20"><b><font color="#FFFFFF">&nbsp;ID</font></b></td>
            <td width="27%" height="20"><b><font color="#FFFFFF">&nbsp;User name</font></b></td>
            <td width="27%" height="20"><b><font color="#FFFFFF">&nbsp;Level</font></b></td>
            <td width="14%" height="20"><b><font color="#FFFFFF">&nbsp;Status</font></b></td>
            <td width="20%" height="20"><b><font color="#FFFFFF">&nbsp;Operation</font></b></td>
        </tr>
<?php
if(!$rs->EOF)
{
	$rs->Move(($currentPage - 1) * PAGE_SIZE);
	$i = 0;
	while(!$rs->EOF && $i < PAGE_SIZE)
	{
		if($i % 2)
		{
			$color = " bgcolor=\"#EFEFEF\"";
		}else {
			$color = "";
		}
?>
        <tr>
          <td height="20" class="p8"<?php echo $color ?>>
            &nbsp;<?php echo $rs->fields[0] ?>
          </td>
          <td height="20" class="p8"<?php echo $color ?>>
            &nbsp;<?php echo $rs->fields[1] ?>
          </td>
          <td height="20" class="p8"<?php echo $color ?>>
            &nbsp;<?php echo $rs->fields[4] ?>
          </td>
          <td height="20" class="p8"<?php echo $color ?>>
<?php
if($rs->fields[3] == 0)
	echo "&nbsp;<font color=\"#0000FF\">Start</font>";
else
	echo "&nbsp;<font color=\"#FF0000\">Stop</font>";
?>
          </td>
          <td height="20" class="p8"<?php echo $color ?>>
            <a href="<?php echo $_SERVER["PHP_SELF"] ?>?action=viewMemberInfo&currentPage=<?php echo $currentPage ?>&member_id=<?php echo $rs->fields[0] ?>"><img src="<?php echo RELA_DIR ?>templates/<?php echo CURRENT_SKIN ?>/images/view.jpg" border="0" alt="View member info"></a>&nbsp;
            <a href="<?php echo $_SERVER["PHP_SELF"] ?>?action=showModifyForm&currentPage=<?php echo $currentPage ?>&member_id=<?php echo $rs->fields[0] ?>"><img src="<?php echo RELA_DIR ?>templates/<?php echo CURRENT_SKIN ?>/images/modify.gif" border="0" alt="Modify member info"></a>&nbsp;
            <a href="<?php echo $_SERVER["PHP_SELF"] ?>?action=deleteMember&currentPage=<?php echo $currentPage ?>&member_id=<?php echo $rs->fields[0] ?>" onClick="return doDelete()"><img src="<?php echo RELA_DIR ?>templates/<?php echo CURRENT_SKIN ?>/images/delete.gif" border="0" alt="Delete member"></a>&nbsp;
          </td>
        </tr>
<?php
		$i ++;
		$rs->MoveNext();
	}
?>
        <tr> 
          <td height="20" bgcolor="#CCCCCC" colspan="5">
<?php
	$webaddress = $_SERVER["PHP_SELF"] . "?action=listMember";
	showPageButton($currentPage, $pageCount, $totalRecord, $webaddress)
?>
          </td>
        </tr>
<?php
}
?>
      </table>
      </form>
    </td>
  </tr>
</table>
<p>&nbsp;</p>