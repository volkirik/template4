<?php
showTitle("Select username");
?>
                  <br>
<?php
showTip("Please input user name, which you are going to register this domain for.");
?>
<br>
<?php
showWarningMsg($message);
?>
<table width="95%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr> 
    <td height="25">
      <br>
      <form action="<?php echo $_SERVER["PHP_SELF"] ?>" method="post" style="margin:0px">
        <input type="hidden" name="action" value="showRegisterForm">
        <input type="hidden" name="domain" value="<?php echo $domain ?>">
        <input type="hidden" name="gtld" value="<?php echo $gtld ?>">
        <table width="95%" border="0" cellspacing="0" cellpadding="0">
          <tr> 
            <td height="30" bgcolor="#EFEFEF" align="center">User name: 
              <input type="text" name="member_name">
            </td>
            <td height="30" bgcolor="#EFEFEF" align="center">
              <input type="submit" name="Submit" value="Continue &gt;&gt;">
            </td>
          </tr>
        </table>
      </form>
      <br>
      <br>
      <b> Note:</b> The registration fee of this domain will be deducted from 
      the account of user name you input. Moreover, the domain will be remained 
      in that user account.<br>
      <br>
    </td>
  </tr>
</table>
                  <p>&nbsp;</p>