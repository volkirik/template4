<html>
<head>
<title><?php echo TITLE ?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="<?php echo RELA_DIR ?>templates/<?php echo CURRENT_SKIN ?>/css/style.css">
</head>

<body bgcolor="#EFEFEF" text="#000000" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table width="750" border="0" align="center" cellspacing="0" cellpadding="0">
  <tr>
    <td colspan="3"><img src="<?php echo RELA_DIR ?>templates/<?php echo CURRENT_SKIN ?>/images/spot.gif" width="1" height="5"></td>
  </tr>
  <tr> 
    <td colspan="3" bgcolor="#000000"><img src="<?php echo RELA_DIR ?>templates/<?php echo CURRENT_SKIN ?>/images/black.gif" width="1" height="1"></td>
  </tr>
  <tr> 
    <td width="1" bgcolor="#000000"><img src="<?php echo RELA_DIR ?>templates/<?php echo CURRENT_SKIN ?>/images/black.gif" width="1" height="1"></td>
    <td width="748" bgcolor="#FFFFFF">
      <table width="748" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td height="40" bgcolor="#FFFFFF" width="160" align="center" colspan="2"><img src="<?php echo RELA_DIR ?>templates/<?php echo CURRENT_SKIN ?>/images/onlinenic.gif" width="135" height="23"></td>
          <td height="40" bgcolor="#98BCED" width="588" colspan="2">&nbsp;</td>
        </tr>
        <tr> 
          <td width="160" height="10" bgcolor="#1F5CAF" colspan="2"><img src="/templates/<?php echo CURRENT_SKIN ?>/images/arrow.gif" width="13" height="9"></td>
          <td width="588" height="20" colspan="2" bgcolor="#1F5CAF"> 
            <table width="100%" border="0" cellspacing="0" cellpadding="0">
              <tr align="center"> 
                <td width="14%"><font color="#FFFFFF"></font></td>
                <td width="14%">&nbsp;</td>
                <td width="14%">&nbsp;</td>
                <td width="14%">&nbsp;</td>
                <td width="14%">&nbsp;</td>
                <td width="14%"><b><a href="<?php echo RELA_DIR ?>admin/logout.php" class="menu1">Logout</a></b></td>
                <td width="14%"><b><a href="<?php echo RELA_DIR ?>help/super_admin.html" class="menu1" target="_blank">Help</a></b></td>
              </tr>
            </table>
          </td>
        </tr>
        <tr> 
      <td bgcolor="#1F5CAF" width="3"><img src="<?php echo RELA_DIR ?>templates/<?php echo CURRENT_SKIN ?>/images/spot.gif"></td>
      <td valign="top" bgcolor="#FFFEF7"> 
        <table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr> 
            <td> 
              <table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
                <tr> 
                  <td bgcolor="#FFCC00" height="3" width="25%"><img src="<?php echo RELA_DIR ?>templates/<?php echo CURRENT_SKIN ?>/images/spot.gif"></td>
                  <td bgcolor="#FFE98E" height="3" width="25%"><img src="<?php echo RELA_DIR ?>templates/<?php echo CURRENT_SKIN ?>/images/spot.gif"></td>
                  <td bgcolor="#FFF3C4" height="3" width="25%"><img src="<?php echo RELA_DIR ?>templates/<?php echo CURRENT_SKIN ?>/images/spot.gif"></td>
                  <td bgcolor="#FFFBE8" height="3" width="25%"><img src="<?php echo RELA_DIR ?>templates/<?php echo CURRENT_SKIN ?>/images/spot.gif"></td>
                </tr>
                <tr> 
                  <td colspan="4">&nbsp;<b><font color="#1F5CAF">Super-admin Area</font></b></td>
                </tr>
                <tr> 
                  <td colspan="4"> 
                    <table width="80%" border="0" cellspacing="0" cellpadding="0" align="center">
                      <tr> 
                        <td><a href="<?php echo RELA_DIR ?>admin/adminList.php" class="menu2">Administrator 
                          List </a></td>
                      </tr>
                      <tr> 
                        <td><a href="<?php echo RELA_DIR ?>admin/systemControl.php" class="menu2">System 
                          Setting</a></td>
                      </tr>
                    </table>
                  </td>
                </tr>
                <tr> 
                  <td colspan="4">&nbsp;</td>
                </tr>
                <tr> 
                  <td colspan="4">&nbsp;<b><font color="#1F5CAF">Product Management</font></b></td>
                </tr>
                <tr> 
                  <td colspan="4"> 
                    <table width="80%" border="0" cellspacing="0" cellpadding="0" align="center">
                      <tr> 
                        <td><a href="<?php echo RELA_DIR ?>admin/productSetting.php" class="menu2">Domain 
                          Setting</a></td>
                      </tr>
                      <tr> 
                        <td><a href="<?php echo RELA_DIR ?>admin/productUpgrade.php" class="menu2">Domain 
                          Upgrade</a></td>
                      </tr>
                      <tr> 
                        <td><a href="<?php echo RELA_DIR ?>admin/domainmanage.php" class="menu2">Manage 
                          Domain </a></td>
                      </tr>
                      <tr>
                        <td><a href="<?php echo RELA_DIR ?>admin/registerdomain.php" class="menu2">Register Domain</a></td>
                      </tr>
                    </table>
                  </td>
                </tr>
                <tr> 
                  <td colspan="4">&nbsp;</td>
                </tr>
                <tr> 
                  <td colspan="4"><b>&nbsp;<b><font color="#1F5CAF">Memeber Management</font></b></b></td>
                </tr>
                <tr> 
                  <td colspan="4"> 
                    <table width="80%" border="0" cellspacing="0" cellpadding="0" align="center">
                      <tr> 
                        <td><a href="<?php echo RELA_DIR ?>admin/memberList.php" class="menu2">Member List</a></td>
                      </tr>
                    </table>
                  </td>
                </tr>
                <tr> 
                  <td colspan="4">&nbsp;</td>
                </tr>
                <tr> 
                  <td colspan="4"><b>&nbsp;<b><font color="#1F5CAF">Account Management</font></b></b></td>
                </tr>
                <tr> 
                  <td colspan="4"> 
                    <table width="80%" border="0" cellspacing="0" cellpadding="0" align="center">
                      <tr> 
                        <td><a href="<?php echo RELA_DIR ?>admin/fundsManage.php" class="menu2">Funds Management</a></td>
                      </tr>
                      <tr> 
                        <td><a href="<?php echo RELA_DIR ?>admin/queryOrder.php" class="menu2">Query Transaction</a></td>
                      </tr>
                    </table>
                  </td>
                </tr>
                <tr>
                  <td colspan="4">&nbsp;</td>
                </tr>
                <tr> 
                  <td colspan="4"><b><b>&nbsp;<b><font color="#1F5CAF">Other operation</font></b></b></b></td>
                </tr>
                <tr> 
                  <td colspan="4"> 
                    <table width="80%" border="0" cellspacing="0" cellpadding="0" align="center">
                      <tr> 
                        <td><a href="<?php echo RELA_DIR ?>admin/whois.php" class="menu2">Whois Search</a></td>
                      </tr>
                    </table>
                  </td>
                </tr>
              </table>
              
            </td>
          </tr>
        </table>
            
        <p>&nbsp;</p>
        <p>&nbsp;</p>
        <p>&nbsp;</p>
        <p>&nbsp;</p>
      </td>
          <td width="1" background="<?php echo RELA_DIR ?>templates/<?php echo CURRENT_SKIN ?>/images/line_1.gif" valign="top"><img src="<?php echo RELA_DIR ?>templates/<?php echo CURRENT_SKIN ?>/images/line_1.gif" width="1" height="4"></td>
          <td width="587" valign="top"> 
            <table width="100%" border="0" cellspacing="0" cellpadding="0">
              <tr> 
                <td align="right"><img src="<?php echo RELA_DIR ?>templates/<?php echo CURRENT_SKIN ?>/images/line_2.gif" width="222" height="6"></td>
              </tr>
            </table>
            <table width="95%" border="0" cellspacing="0" cellpadding="0" align="center">
              <tr>
                <td>