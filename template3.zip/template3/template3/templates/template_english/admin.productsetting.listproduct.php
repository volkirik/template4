<?php
global $admin_info;
showTitle("Domain Setting");
?>
<br>
<table width="95%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr>
    <td>
      <form style="margin:0px">
        <table width="95%" border="0" cellspacing="1" cellpadding="0" align="center">
          <tr bgcolor="#999999"> 
            <td width="12%" height="20"><b><font color="#FFFFFF">&nbsp;ID</font></b></td>
            <td width="27%" height="20"><b><font color="#FFFFFF">&nbsp;Product 
              Name</font></b></td>
            <td width="27%" height="20"><b><font color="#FFFFFF">&nbsp;Product 
              Type</font></b></td>
            <td width="12%" height="20"><b><font color="#FFFFFF">&nbsp;Status</font></b></td>
            <td width="22%" height="20"><b><font color="#FFFFFF">&nbsp;Operation</font></b></td>
        </tr>
<?php
if(!$rs->EOF)
{
	$rs->Move(($currentPage - 1) * PAGE_SIZE);
	$i = 0;
	while(!$rs->EOF && $i < PAGE_SIZE)
	{
		if($i % 2)
		{
			$color = " bgcolor=\"#EFEFEF\"";
		}else {
			$color = "";
		}
?>
        <tr>
          <td height="20" class="p8"<?php echo $color ?>>
            &nbsp;<?php echo $rs->fields[1] ?>
          </td>
          <td height="20" class="p8"<?php echo $color ?>>
            &nbsp;<?php echo $rs->fields[3] ?>
          </td>
          <td height="20" class="p8"<?php echo $color ?>>
<?php
if($rs->fields[4] == 1)
{
	echo "&nbsp;Domain";
}else if($rs->fields[3] == 2) {
	echo "&nbsp;Hosting";
}else if($rs->fields[3] == 3) {
	echo "&nbsp;Postoffice";
}
?>
          </td>
          <td height="20" class="p8"<?php echo $color ?>>
<?php
if($rs->fields[5] == 0)
	echo "&nbsp;<font color=\"#0000FF\">Start</font>";
else
	echo "&nbsp;<font color=\"#FF0000\">Stop</font>";
?>
          </td>
          <td height="20" class="p8"<?php echo $color ?>>
            <a href="<?php echo $_SERVER["PHP_SELF"] ?>?action=showModifyDNS&currentPage=<?php echo $currentPage ?>&product_id=<?php echo $rs->fields[1] ?>">DNS</a>&nbsp;
            <a href="<?php echo $_SERVER["PHP_SELF"] ?>?action=showModifyPrice&currentPage=<?php echo $currentPage ?>&product_id=<?php echo $rs->fields[1] ?>">Price</a>&nbsp;
<?php
if($rs->fields[5] == 0)
{
?>
            <a href="<?php echo $_SERVER["PHP_SELF"] ?>?action=stopProduct&currentPage=<?php echo $currentPage ?>&product_id=<?php echo $rs->fields[1] ?>">Stop</a>&nbsp;
<?php
}else {
?>
            <a href="<?php echo $_SERVER["PHP_SELF"] ?>?action=startProduct&currentPage=<?php echo $currentPage ?>&product_id=<?php echo $rs->fields[1] ?>">Start</a>&nbsp;
<?php
}
?>
          </td>
        </tr>
<?php
		$i ++;
		$rs->MoveNext();
	}
?>
        <tr> 
          <td height="20" bgcolor="#CCCCCC" colspan="5">
<?php
	$webaddress = $_SERVER["PHP_SELF"] . "?action=listProduct";
	showPageButton($currentPage, $pageCount, $totalRecord, $webaddress)
?>
          </td>
        </tr>
<?php
}
?>
      </table>
      </form>
    </td>
  </tr>
</table>
<p>&nbsp;</p>