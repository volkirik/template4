<?php
showTitle("Member login");
?>
                  <br>
<?php
showTip("Please input your username and password to login.");
showWarningMsg($message);
?>
<table width="95%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr> 
    <td >
	  <form action="<?php echo RELA_DIR ?>member/login.php" method="post" style="margin:0px">
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td align="right" width="40%">Username:</td>
          <td width="60%"> 
              <input type="text" name="username">
          </td>
        </tr>
        <tr> 
          <td align="right" width="40%">Password:</td>
          <td width="60%"> 
              <input type="password" name="password">
          </td>
        </tr>
        <tr> 
          <td align="right" width="40%">&nbsp;</td>
          <td width="60%">&nbsp;</td>
        </tr>
        <tr>
          <td align="right" width="40%">&nbsp;</td>
          <td width="60%">
            <input type="submit" name="Submit" value="Login">
          </td>
        </tr>
      </table>
	  </form>
      <p align="center"><br>
        Forgot your password? <a href="<?php echo RELA_DIR ?>member/getpassword.php">Click here</a>.<br>
        <br>
        If you are not yet a member, <a href="<?php echo RELA_DIR ?>member/signup.php">click here</a> 
        to signup!</p>
      </td>
  </tr>
</table>
                  <p>&nbsp;</p>