<?php
showTitle("Whois Result");
?>
                  <br>
                  
<table width="95%" border="0" cellspacing="0" cellpadding="0" align="center">
   <tr>
     
    <td width="25%" height="25" colspan="2">&nbsp; </td>
  </tr>
  <tr> 
    <td>
	  <pre><?php echo $result ?></pre>
    </td>
  </tr>
</table>
                  <p>&nbsp;</p>