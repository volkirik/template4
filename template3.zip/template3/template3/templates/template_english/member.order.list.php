<?php
global $member_info;
showTitle("Order history");
?>
                  <br>
<table width="95%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr>
    <td> <b><br>
      </b> 
      <table width="50%" border="0" cellspacing="1" cellpadding="2" class="border1" align="center">
        <tr> 
          <td height="20" width="30%" bgcolor="#E1ECFB"><b>Account</b></td>
          <td height="20" width="70%" bgcolor="#F2F8FD"> <b>
            <?php echo $member_info[1] ?>
            </b></td>
        </tr>
        <tr> 
          <td height="20" width="30%" bgcolor="#E1ECFB"><b>Level</b></td>
          <td height="20" width="70%" bgcolor="#F2F8FD"> <b>
            <?php echo $member_info[4] ?>
            </b></td>
        </tr>
        <tr> 
          <td height="20" width="30%" bgcolor="#E1ECFB"><b>Balance</b></td>
          <td height="20" width="70%" bgcolor="#F2F8FD"> <font color="#000000">$ 
            <?php echo $member_info[6] ?>
            </font></td>
        </tr>
      </table>
      <b><br>
      <br>
      My order history</b><br>
      <hr size="1">
      <br>
      <form action="<?php echo $_SERVER["PHP_SELF"] ?>" method="post" style="margin:0px">
        <table width="95%" border="0" cellspacing="0" cellpadding="0" align="center" bgcolor="#E1ECFB" class="border1">
          <tr>
            <td>
              <table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
                <tr> 
                  <td> Time: 
                    <select name="startYear">
                      <option>Year</option>
                      <?php
for($i_year = 2002; $i_year < 2006; $i_year ++)
{
	if($startYear == $i_year)
	{
		echo "<option value=" . $i_year . " selected>" . $i_year;
	}else {
		echo "<option value=" . $i_year . ">" . $i_year;
	}
}
?>
                    </select>
                    <select name="startMonth">
                      <option>Mon</option>
                      <?php
for($i_month = 1; $i_month < 13; $i_month ++)
{
	if($startMonth == $i_month)
	{
		echo "<option value=" . $i_month . " selected>" . $i_month;
	}else {
		echo "<option value=" . $i_month . ">" . $i_month;
	}
}
?>
                    </select>
                    <select name="startDay">
                      <option>Day</option>
                      <?php
for($i_day = 1; $i_day < 32; $i_day ++)
{
	if($startDay == $i_day)
	{
		echo "<option value=" . $i_day . " selected>" . $i_day;
	}else {
		echo "<option value=" . $i_day . ">" . $i_day;
	}
}
?>
                    </select>
                    to 
                    <select name="toYear">
                      <option>Year</option>
                      <?php
for($i_year = 2002; $i_year < 2006; $i_year ++)
{
	if($toYear == $i_year)
	{
		echo "<option value=" . $i_year . " selected>" . $i_year;
	}else {
		echo "<option value=" . $i_year . ">" . $i_year;
	}
}
?>
                    </select>
                    <select name="toMonth">
                      <option>Mon</option>
                      <?php
for($i_month = 1; $i_month < 13; $i_month ++)
{
	if($toMonth == $i_month)
	{
		echo "<option value=" . $i_month . " selected>" . $i_month;
	}else {
		echo "<option value=" . $i_month . ">" . $i_month;
	}
}
?>
                    </select>
                    <select name="toDay">
                      <option>Day</option>
                      <?php
for($i_day = 1; $i_day < 32; $i_day ++)
{
	if($toDay == $i_day)
	{
		echo "<option value=" . $i_day . " selected>" . $i_day;
	}else {
		echo "<option value=" . $i_day . ">" . $i_day;
	}
}
?>
                    </select>
                  </td>
                </tr>
              </table>
              <br>
              <table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
                <tr> 
                  <td width="10%">Product: </td>
                  <td width="18%"> 
                    <select name="product_id">
                      <option>All</option>
                      <?php
$sql = "select * from products";
$rs2 = $conn->Execute($sql);
if(!$rs2)
{
	showErrorMsg($conn->ErrorMsg());
}
while(!$rs2->EOF)
{
	if($rs2->fields[1] == $product_id)
	{
		echo "<option value=\"" . $rs2->fields[1] . "\" selected>" . $rs2->fields[3];
	}else {
		echo "<option value=\"" . $rs2->fields[1] . "\">" . $rs2->fields[3];
	}
	$rs2->MoveNext();
}
?>
                    </select>
                  </td>
                  <td width="14%">Transation: </td>
                  <td width="18%"> 
                    <select name="transation">
                      <?php
if($transation == "1,2")
{
?>
                      <option value="1,2" selected>All</option>
                      <option value="1">Deposit</option>
                      <option value="2">Payment</option>
                      <?php
}else if($transation == "1") {
?>
                      <option value="1,2">All</option>
                      <option value="1" selected>Deposit</option>
                      <option value="2">Payment</option>
                      <?php
}else {
?>
                      <option value="1,2">All</option>
                      <option value="1">Deposit</option>
                      <option value="2" selected>Payment</option>
                      <?php
}
?>
                    </select>
                  </td>
                  <td width="40%"> 
                    <input type="submit" name="Submit" value="Query">
                  </td>
                </tr>
              </table>
            </td>
          </tr>
        </table>
        <br>
        <br>
      </form>
      <form style="margin:0px">
        <table width="95%" border="0" cellspacing="1" cellpadding="0" align="center">
          <tr bgcolor="#999999"> 
            <td width="18%" height="20"><b><font color="#FFFFFF">&nbsp;Transaction</font></b></td>
            <td width="26%" height="20"><b><font color="#FFFFFF">&nbsp;Time</font></b></td>
            <td width="14%" height="20"><b><font color="#FFFFFF">&nbsp;Amount</font></b></td>
            <td width="22%" height="20"><b><font color="#FFFFFF">&nbsp;Mode</font></b></td>
            <td width="20%" height="20"><b><font color="#FFFFFF">&nbsp;Note</font></b></td>
        </tr>
<?php
if(!$rs->EOF)
{
	$rs->Move(($currentPage - 1) * PAGE_SIZE);
	$i = 0;
	while(!$rs->EOF && $i < PAGE_SIZE)
	{
		if($i % 2)
		{
			$color = " bgcolor=\"#EFEFEF\"";
		}else {
			$color = "";
		}
?>
        <tr>
          <td height="20" class="p8"<?php echo $color ?>>
<?php
		if($rs->fields[3] == 1)
		{
			echo "deposit";
		}else {
			echo "payment";
		}
?>
          </td>
          <td height="20" class="p8"<?php echo $color ?>>
            <?php echo $rs->fields[2] ?>
          </td>
          <td height="20" class="p8"<?php echo $color ?>>
            <?php echo $rs->fields[5] ?>
          </td>
          <td height="20" class="p8"<?php echo $color ?>>
<?php
		$mode_id = $rs->fields[4];
		$sql = "select * from ordermode where mode_id = " . $mode_id . " and mode_lan = ". WEBSITE_LANGUAGE;
		$rs1 = $conn->Execute($sql);
		if(!$rs1)
		{
			showErrorMsg($conn->ErrorMsg());
		}
		echo $rs1->fields[3];
?>
          </td>
          <td height="20" class="p8"<?php echo $color ?>>
            <?php echo $rs->fields[8] ?>
          </td>
        </tr>
<?php
		$i ++;
		$rs->MoveNext();
	}
?>
        <tr> 
          <td height="20" bgcolor="#CCCCCC" colspan="5">
<?php
	$webaddress = $_SERVER["PHP_SELF"] . "?transation=" . $transation . "&startYear=" . $startYear . "&startMonth=" . $startMonth . "&startDay=" . $startDay . "&toYear=" . $toYear . "&toMonth=" . $toMonth . "&toDay=" . $toDay . "&product_id=" . $product_id;
	showPageButton($currentPage, $pageCount, $totalRecord, $webaddress)
?>
          </td>
        </tr>
<?php
}
?>
      </table>
      <input type="hidden" name="transation" value="<?php echo $transation ?>">
      </form>
      
    </td>
  </tr>
</table>
                  <p>&nbsp;</p>