<?php
showTitle("Forgot password");
?>
                  <br>
<?php
showTip("Please input your correct username and E-mail address to retrieve the password. Once you complete inputting the correct information, an E-mail with your password will be automatically sent to you.");
showWarningMsg($message);
?>
<table width="95%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr> 
    <td >
      <form action="<?php echo RELA_DIR ?>member/getpassword.php" method="post" style="margin:0px">
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr> 
            <td align="right" width="40%">Username:</td>
          <td width="60%"> 
              <input type="text" name="username" value="<?php echo StripSlashes($_POST["username"]) ?>">
          </td>
        </tr>
        <tr> 
            <td align="right" width="40%">E-mail:</td>
          <td width="60%"> 
              <input type="text" name="email" value="<?php echo StripSlashes($_POST["email"]) ?>">
          </td>
        </tr>
        <tr> 
          <td align="right" width="40%">&nbsp;</td>
          <td width="60%">&nbsp;</td>
        </tr>
        <tr>
          <td align="right" width="40%">&nbsp;</td>
          <td width="60%">
              <input type="submit" name="Submit" value="Get password">
          </td>
        </tr>
      </table>
	  </form>
      <p align="center"><br>
        <br>
        <br>
        If you are not yet a member, <a href="<?php echo RELA_DIR ?>member/signup.php">click here</a> 
        to signup!</p>
      </td>
  </tr>
</table>
                  <p>&nbsp;</p>