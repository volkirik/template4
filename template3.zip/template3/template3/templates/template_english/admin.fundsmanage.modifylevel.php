<?php
showTitle("Modify member level");
?>
                  <br>
<?php
showTip("If you want to modify member level after funds activity, please reset it for this member in following panel. ");
?>
<br>
<?php
showWarningMsg($message);
?>
<table width="95%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr> 
    <td height="25">
      <br>
      <form action="<?php echo $_SERVER["PHP_SELF"] ?>" method="post" style="margin:0px">

        <input type="hidden" name="action" value="modifyLevel">
        <input type="hidden" name="member_name" value="<?php echo $member_name ?>">
        <b><font color="#FF0000">Success!</font></b> <b>$<?php echo $amount ?></b>
        has been 
<?php
if($type == 1)
{
	echo "added";
}else {
	echo "deducted";
}
?>
         to the account of 
        <b><?php echo $member_name ?></b>.<br>
        The current member level is 
        <b><?php echo $member_level ?></b>, would you like to re-set its member level?<br>
        <br>
        <br>
        <table width="95%" border="0" cellspacing="0" cellpadding="0">
          <tr> 
            <td height="30" bgcolor="#EFEFEF" align="center">Member level: 
              <select name="member_level">
                <?php
if($member_level == 0)
{
?>
                <option value="0" selected>0</option>
                <option value="1">1</option>
                <option value="2">2</option>
                <option value="3">3</option>
                <option value="4">4</option>
                <?php
}else if($member_level == 1) {
?>
                <option value="0">0</option>
                <option value="1" selected>1</option>
                <option value="2">2</option>
                <option value="3">3</option>
                <option value="4">4</option>
                <?php
}else if($member_level == 2) {
?>
                <option value="0">0</option>
                <option value="1">1</option>
                <option value="2" selected>2</option>
                <option value="3">3</option>
                <option value="4">4</option>
                <?php
}else if($member_level == 3) {
?>
                <option value="0">0</option>
                <option value="1">1</option>
                <option value="2">2</option>
                <option value="3" selected>3</option>
                <option value="4">4</option>
                <?php
}else if($member_level == 4) {
?>
                <option value="0">0</option>
                <option value="1">1</option>
                <option value="2">2</option>
                <option value="3">3</option>
                <option value="4" selected>4</option>
                <?php
}else {
?>
                <option value="0" selected>0</option>
                <option value="1">1</option>
                <option value="2">2</option>
                <option value="3">3</option>
                <option value="4">4</option>
                <?php
}
?>
              </select>
            </td>
            <td height="30" bgcolor="#EFEFEF" align="center">
              <input type="submit" name="Submit" value="   OK   ">
              <input type="button" name="back" value="Cancel" onClick="document.location.href='<?php echo RELA_DIR ?>admin/fundsManage.php'">
            </td>
          </tr>
        </table>
      </form>
      <br>
    </td>
  </tr>
</table>
                  <p>&nbsp;</p>