<?php
showTitle("Check result");
?>
                  <br>
                  
<table width="95%" border="0" cellspacing="0" cellpadding="0" align="center">
   <tr>
     
    <td width="25%" height="25" colspan="2"><b>
<?php
if($result == 1)
{
	echo "The follow domain are unavailable";
}else {
	echo "The follow domain are available";
}
?>
    </b><br>
      <br>
      <form action="<?php echo $_SERVER["PHP_SELF"] ?>" method="post" style="margin:0px">
      <input type="hidden" name="action" value="showRegisterForm">
      <input type="hidden" name="domain" value="<?php echo $domain ?>">
      <input type="hidden" name="gtld" value="<?php echo $gtld ?>">
      <table width="95%" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td height="30" bgcolor="#EFEFEF" align="center">
<?php
if($result == 1)
{
	echo $real_domain;
}else {
	echo $real_domain;
	echo "</td><td bgcolor=\"#EFEFEF\"><input type=\"submit\" name=\"Submit\" value=\"Register >>\">";
}
?>
          </td>
        </tr>
      </table>
      </form>
      <br>
      <br>
      If you want to check more domain names, please enter the domain name below 
      and click Check to check domain.<br>
      <br>
    </td>
  </tr>
  <tr> 
    <td >
	  <form action="<?php echo $_SERVER["PHP_SELF"] ?>" method="post" style="margin:0px">
        <table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr> 
            <td align="right" width="26%">www.</td>
            <td width="38%"> 
              <input type="text" name="domain">
              <select name="gtld">
<?php
while(!$rs->EOF)
{
	echo "<option value=\"" . $rs->fields[1] . "\">" . $rs->fields[3];
	$rs->MoveNext();
}
?>
              </select>
            </td>
            <td width="36%"> 
              <input type="submit" name="Submit" value="Check">
              <input type="hidden" name="action" value="checkDomain">
            </td>
          </tr>
        </table>
	  </form>
      <p><br>
        <br>
        <b>Domain Name Format: </b><br>
        A domain name is a random composition of case insensitive English letters, 
        numbers and the hyphen. The string can not exceed 67 characters in length. 
        The hyphen ('-') can not appear at the beginning or the end of the character 
        string. For example, 'eat-at-joes.com' is a valid domain name, '-eatatjoes.com' 
        is not.</p>
      </td>
  </tr>
</table>
                  <p>&nbsp;</p>