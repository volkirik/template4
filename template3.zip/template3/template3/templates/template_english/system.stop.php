<?php
showTitle("System status");
?>
<p><br>
  
</p><p>&nbsp;</p><table width="80%" border="0" cellspacing="0" cellpadding="0" align="center" style="border:solid 1px #878DC7;padding:5px">
  <tr bgcolor="#EFEFEF"> 
    <td height="100" align="center" bgcolor="#F2F7F9"><b>Sorry, the system is 
      in the maintenance</b></td>
  </tr>
</table>
<p>&nbsp;</p>