<?php
global $admin_info;
showTitle("Member List &gt; Modify member information");
?>
<br>
<form action="<?php echo $_SERVER["PHP_SELF"] ?>" method="post">
  <table width="80%" border="0" cellspacing="0" cellpadding="0" align="center">
    <?php
if($message <> "")
{
?>
    <tr> 
      <td width="25%" height="25" colspan="2"> 
        <div style="border:solid 1px #FF0000;padding:5px"> <font class="p8"><b> 
          <?php echo $message ?>
          </b></font> </div>
      </td>
    </tr>
    <tr> 
      <td width="25%" height="25" colspan="2">&nbsp; </td>
    </tr>
    <?php
}
?>
    <tr> 
      <td colspan="2" height="25">
        <table width="100%" border="0" cellspacing="1" cellpadding="2" class="border1">
          <tr> 
            <td height="20" width="20%" bgcolor="#E1ECFB"><b>ID</b></td>
            <td height="20" width="30%" bgcolor="#F2F8FD"><?php echo $member_id ?></td>
            <td height="20" width="20%" bgcolor="#E1ECFB"><b>Level</b></td>
            <td height="20" width="30%" bgcolor="#F2F8FD">
              <select name="member_level">
<?php
if($member_level == 0)
{
?>
				<option value="0" selected>0</option>
				<option value="1">1</option>
				<option value="2">2</option>
				<option value="3">3</option>
				<option value="4">4</option>
<?php
}else if($member_level == 1) {
?>
				<option value="0">0</option>
				<option value="1" selected>1</option>
				<option value="2">2</option>
				<option value="3">3</option>
				<option value="4">4</option>
<?php
}else if($member_level == 2) {
?>
				<option value="0">0</option>
				<option value="1">1</option>
				<option value="2" selected>2</option>
				<option value="3">3</option>
				<option value="4">4</option>
<?php
}else if($member_level == 3) {
?>
				<option value="0">0</option>
				<option value="1">1</option>
				<option value="2">2</option>
				<option value="3" selected>3</option>
				<option value="4">4</option>
<?php
}else if($member_level == 4) {
?>
				<option value="0">0</option>
				<option value="1">1</option>
				<option value="2">2</option>
				<option value="3">3</option>
				<option value="4" selected>4</option>
<?php
}else {
?>
				<option value="0" selected>0</option>
				<option value="1">1</option>
				<option value="2">2</option>
				<option value="3">3</option>
				<option value="4">4</option>
<?php
}
?>
              </select>
            </td>
          </tr>
          <tr> 
            <td height="20" width="20%" bgcolor="#E1ECFB"><b>Username</b></td>
            <td height="20" width="30%" bgcolor="#F2F8FD"><?php echo $member_name ?></td>
            <td height="20" width="20%" bgcolor="#E1ECFB"><b>Account</b></td>
            <td height="20" width="30%" bgcolor="#F2F8FD"><?php echo $account ?></td>
          </tr>
          <tr> 
            <td height="20" width="20%" bgcolor="#E1ECFB"><b>Status</b></td>
            <td height="20" width="30%" bgcolor="#F2F8FD">
<?php
if($flag == 0)
{
?>
              <input type="checkbox" name="flag" value="1">
<?php
}else {
?>
              <input type="checkbox" name="flag" value="1" checked>
<?php
}
?>
              Accout is disabled</td>
            <td height="20" width="20%" bgcolor="#E1ECFB"><b>Reg Time</b></td>
            <td height="20" width="30%" bgcolor="#F2F8FD"><?php echo $reg_time ?></td>
          </tr>
        </table>
      </td>
    </tr>
    <tr> 
      <td colspan="2" height="25"><b><br>
        <br>
        Registrant information</b></td>
    </tr>
    <tr> 
      <td colspan="2" height="25"> 
        <table width="100%" border="0" cellspacing="1" cellpadding="2" class="border1">
          <tr> 
            <td width="30%" height="20" bgcolor="#EFEFEF">Registrant</td>
            <td width="70%" height="20"> 
              <input type="text" name="r_name" value="<?php echo $r_name ?>">
              
            </td>
          </tr>
          <tr> 
            <td width="30%" height="20" bgcolor="#EFEFEF">Organization</td>
            <td width="70%" height="20"> 
              <input type="text" name="r_org" value="<?php echo $r_org ?>">
            </td>
          </tr>
          <tr> 
            <td width="30%" height="20" bgcolor="#EFEFEF">Address 1</td>
            <td width="70%" height="20"> 
              <input type="text" name="r_address1" value="<?php echo $r_address1 ?>" size="30">
            </td>
          </tr>
          <tr> 
            <td width="30%" height="20" bgcolor="#EFEFEF">Address 2</td>
            <td width="70%" height="20"> 
              <input type="text" name="r_address2" value="<?php echo $r_address2 ?>" size="30">
            </td>
          </tr>
          <tr> 
            <td width="30%" height="20" bgcolor="#EFEFEF">Address 3</td>
            <td width="70%" height="20"> 
              <input type="text" name="r_address3" value="<?php echo $r_address3 ?>" size="30">
            </td>
          </tr>
          <tr> 
            <td width="30%" height="20" bgcolor="#EFEFEF">City</td>
            <td width="70%" height="20"> 
              <input type="text" name="r_city" value="<?php echo $r_city ?>">
            </td>
          </tr>
          <tr> 
            <td width="30%" height="20" bgcolor="#EFEFEF">Province/State</td>
            <td width="70%" height="20"> 
              <input type="text" name="r_province" value="<?php echo $r_province ?>">
            </td>
          </tr>
          <tr> 
            <td width="30%" height="20" bgcolor="#EFEFEF">Country</td>
            <td width="70%" height="20">
        <select name="r_country">
<?php
while(!$rs->EOF)
{
	if($rs->fields[1] == $r_country)
		echo "<option value=\"" . $rs->fields[1] . "\" selected>" . $rs->fields[0] . "\n";
	else
		echo "<option value=\"" . $rs->fields[1] . "\">" . $rs->fields[0] . "\n";
	$rs->MoveNext();
}
?>
        </select>
            </td>
          </tr>
          <tr> 
            <td width="30%" height="20" bgcolor="#EFEFEF">Postalcode</td>
            <td width="70%" height="20">
              <input type="text" name="r_postalcode" value="<?php echo $r_postalcode ?>">
            </td>
          </tr>
          <tr> 
            <td width="30%" height="20" bgcolor="#EFEFEF">Telephone</td>
            <td width="70%" height="20">
              <input type="text" name="r_telephone" value="<?php echo $r_telephone ?>">
            </td>
          </tr>
          <tr> 
            <td width="30%" height="20" bgcolor="#EFEFEF">Fax</td>
            <td width="70%" height="20">
              <input type="text" name="r_fax" value="<?php echo $r_fax ?>">
            </td>
          </tr>
          <tr>
            <td width="30%" height="20" bgcolor="#EFEFEF">E-mail</td>
            <td width="70%" height="20">
              <input type="text" name="r_email" value="<?php echo $r_email ?>">
            </td>
          </tr>
        </table>
      </td>
    </tr>
    <tr> 
      <td width="30%" height="25">&nbsp;</td>
      <td width="70%" height="25">&nbsp;</td>
    </tr>
    <tr> 
      <td width="30%" height="25">&nbsp;</td>
      <td width="70%" height="25"> 
        <input type="submit" name="Submit" value="Modify member info">
        <input type="hidden" name="action" value="modifyMemberInfo">
        <input type="hidden" name="member_id" value="<?php echo $member_id ?>">
        <input type="hidden" name="currentPage" value="<?php echo $_REQUEST["currentPage"] ?>">
      </td>
    </tr>
  </table>
</form>
<p>&nbsp;</p>