<?php
showTitle("Modify domain contact");
?>
                  <br>
<?php
showTip("Please input the new contact information directly to replace the old one.");
showWarningMsg($message);
?>
<table width="95%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr> 
    <td >
	<form action="<?php echo $_SERVER["PHP_SELF"] ?>" method="post" style="margin:0px">
	<input type="hidden" name="action" value="modifyContact">
	<input type="hidden" name="domain_id" value="<?php echo $domain_id ?>">
	<input type="hidden" name="registrant" value="<?php echo $registrant ?>">
        <table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr> 
            <td width="25%">Password for domain:</td>
            <td width="25%"> 
              <input type="password" name="password1" value="<?php echo $password1 ?>">
            </td>
            <td width="20%">Password again:</td>
            <td width="30%"> 
              <input type="password" name="password2" value="<?php echo $password2 ?>">
            </td>
          </tr>
        </table>
	    <br>
        <br>
        <b>Resistrant Information</b><br>
        <hr size="1" noshade>
        <table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr> 
            <td width="39%">Registrant full name</td>
            <td width="61%"> 
             <?php echo $registrant ?>
            </td>
          </tr>
          <tr> 
            <td width="39%">Organization name</td>
            <td width="61%"> 
              <input type="text" name="r_org" value="<?php echo $r_org ?>">
              <font color="#990000">*</font> </td>
          </tr>
          <tr> 
            <td width="39%">Address 1</td>
            <td width="61%"> 
              <input type="text" name="r_address1" value="<?php echo $r_address1 ?>" size="30">
              <font color="#990000">*</font></td>
          </tr>
          <tr> 
            <td width="39%">Address 2</td>
            <td width="61%"> 
              <input type="text" name="r_address2" value="<?php echo $r_address2 ?>" size="30">
              <font color="#990000">*</font></td>
          </tr>
          <tr> 
            <td width="39%">Address 3</td>
            <td width="61%"> 
              <input type="text" name="r_address3" value="<?php echo $r_address3 ?>" size="30">
              <font color="#990000">*</font></td>
          </tr>
          <tr> 
            <td width="39%">City</td>
            <td width="61%"> 
              <input type="text" name="r_city" value="<?php echo $r_city ?>">
              <font color="#990000">*</font></td>
          </tr>
          <tr> 
            <td width="39%">Province/State</td>
            <td width="61%"> 
              <input type="text" name="r_province" value="<?php echo $r_province ?>">
              <font color="#990000">*</font></td>
          </tr>
          <tr> 
            <td width="39%">Country/Region</td>
            <td width="61%">
              <select name="r_country">
<?php
	while(list($key, $val) = each($countries))
	{
		if($key == $r_country)
		{
			echo "<option value=\"" . $key . "\" selected>" . $val . "</option>\n";
		}else {
			echo "<option value=\"" . $key . "\">" . $val . "</option>\n";
		}
	}
?>
              </select><font color="#990000">*</font></td>
          </tr>
          <tr> 
            <td width="39%">Postal code</td>
            <td width="61%"> 
              <input type="text" name="r_postalcode" value="<?php echo $r_postalcode ?>">
              <font color="#990000">*</font></td>
          </tr>
          <tr> 
            <td width="39%">Telephone(eg:+1.4156656387)</td>
            <td width="61%"> 
              <input type="text" name="r_telephone" value="<?php echo $r_telephone ?>">
              <font color="#990000">*</font></td>
          </tr>
          <tr> 
            <td width="39%">Fax(eg:+1.4156657168)</td>
            <td width="61%"> 
              <input type="text" name="r_fax" value="<?php echo $r_fax ?>">
              <font color="#990000">*</font></td>
          </tr>
          <tr>
            <td width="39%">E-mail</td>
            <td width="61%">
              <input type="text" name="r_email" value="<?php echo $r_email ?>" size="30">
              <font color="#990000">*</font></td>
          </tr>
        </table>
        <br>
        <b>Administrator Information</b><br>
        <hr size="1" noshade>
        <table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr> 
            <td width="39%">Full name of administrator</td>
            <td width="61%"> 
              <input type="text" name="administrator" value="<?php echo $administrator ?>">
              <font color="#990000">*</font> </td>
          </tr>
          <tr> 
            <td width="39%">Organization name</td>
            <td width="61%"> 
              <input type="text" name="a_org" value="<?php echo $a_org ?>">
              <font color="#990000">*</font> </td>
          </tr>
          <tr> 
            <td width="39%">Address 1</td>
            <td width="61%"> 
              <input type="text" name="a_address1" value="<?php echo $a_address1 ?>" size="30">
              <font color="#990000">*</font></td>
          </tr>
          <tr> 
            <td width="39%">Address 2</td>
            <td width="61%"> 
              <input type="text" name="a_address2" value="<?php echo $a_address2 ?>" size="30">
              <font color="#990000">*</font></td>
          </tr>
          <tr> 
            <td width="39%">Address 3</td>
            <td width="61%"> 
              <input type="text" name="a_address3" value="<?php echo $a_address3 ?>" size="30">
              <font color="#990000">*</font></td>
          </tr>
          <tr> 
            <td width="39%">City</td>
            <td width="61%"> 
              <input type="text" name="a_city" value="<?php echo $a_city ?>">
              <font color="#990000">*</font></td>
          </tr>
          <tr> 
            <td width="39%">Province/State</td>
            <td width="61%"> 
              <input type="text" name="a_province" value="<?php echo $a_province ?>">
              <font color="#990000">*</font></td>
          </tr>
          <tr> 
            <td width="39%">Country/Region</td>
            <td width="61%"> 
              <select name="a_country">
<?php
	reset($countries);
	while(list($key, $val) = each($countries))
	{
		if($key == $a_country)
		{
			echo "<option value=\"" . $key . "\" selected>" . $val . "</option>";
		}else {
			echo "<option value=\"" . $key . "\">" . $val . "</option>";
		}
	}
?>
              </select><font color="#990000">*</font></td>
          </tr>
          <tr> 
            <td width="39%">Postal code</td>
            <td width="61%"> 
              <input type="text" name="a_postalcode" value="<?php echo $a_postalcode ?>">
              <font color="#990000">*</font></td>
          </tr>
          <tr> 
            <td width="39%">Telephone(eg:+1.4156656387)</td>
            <td width="61%"> 
              <input type="text" name="a_telephone" value="<?php echo $a_telephone ?>">
              <font color="#990000">*</font></td>
          </tr>
          <tr> 
            <td width="39%">Fax(eg:+1.4156657168)</td>
            <td width="61%"> 
              <input type="text" name="a_fax" value="<?php echo $a_fax ?>">
              <font color="#990000">*</font></td>
          </tr>
          <tr> 
            <td width="39%">E-mail</td>
            <td width="61%"> 
              <input type="text" name="a_email" value="<?php echo $a_email ?>" size="30">
              <font color="#990000">*</font></td>
          </tr>
        </table>
        <b><br>
        Technical Contact Information</b><br>
        <hr size="1" noshade>
        <table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr> 
            <td width="39%">Full name of technical contact</td>
            <td width="61%"> 
              <input type="text" name="technical" value="<?php echo $technical ?>">
              <font color="#990000">*</font> </td>
          </tr>
          <tr> 
            <td width="39%">Organization name</td>
            <td width="61%"> 
              <input type="text" name="t_org" value="<?php echo $t_org ?>">
              <font color="#990000">*</font> </td>
          </tr>
          <tr> 
            <td width="39%">Address 1</td>
            <td width="61%"> 
              <input type="text" name="t_address1" value="<?php echo $r_address1 ?>" size="30">
              <font color="#990000">*</font></td>
          </tr>
          <tr> 
            <td width="39%">Address 2</td>
            <td width="61%"> 
              <input type="text" name="t_address2" value="<?php echo $t_address2 ?>" size="30">
              <font color="#990000">*</font></td>
          </tr>
          <tr> 
            <td width="39%">Address 3</td>
            <td width="61%"> 
              <input type="text" name="t_address3" value="<?php echo $t_address3 ?>" size="30">
              <font color="#990000">*</font></td>
          </tr>
          <tr> 
            <td width="39%">City</td>
            <td width="61%"> 
              <input type="text" name="t_city" value="<?php echo $t_city ?>">
              <font color="#990000">*</font></td>
          </tr>
          <tr> 
            <td width="39%">Province/State</td>
            <td width="61%"> 
              <input type="text" name="t_province" value="<?php echo $t_province ?>">
              <font color="#990000">*</font></td>
          </tr>
          <tr> 
            <td width="39%">Country/Region</td>
            <td width="61%"> 
              <select name="t_country">
<?php
	reset($countries);
	while(list($key, $val) = each($countries))
	{
		if($key == $t_country)
		{
			echo "<option value=\"" . $key . "\" selected>" . $val . "</option>";
		}else {
			echo "<option value=\"" . $key . "\">" . $val . "</option>";
		}
	}
?>
              </select><font color="#990000">*</font></td>
          </tr>
          <tr> 
            <td width="39%">Postal code</td>
            <td width="61%"> 
              <input type="text" name="t_postalcode" value="<?php echo $t_postalcode ?>">
              <font color="#990000">*</font></td>
          </tr>
          <tr> 
            <td width="39%">Telephone(eg:+1.4156656387)</td>
            <td width="61%"> 
              <input type="text" name="t_telephone" value="<?php echo $t_telephone ?>">
              <font color="#990000">*</font></td>
          </tr>
          <tr> 
            <td width="39%">Fax(eg:+1.4156657168)</td>
            <td width="61%"> 
              <input type="text" name="t_fax" value="<?php echo $t_fax ?>">
              <font color="#990000">*</font></td>
          </tr>
          <tr> 
            <td width="39%">E-mail</td>
            <td width="61%"> 
              <input type="text" name="t_email" value="<?php echo $t_email ?>" size="30">
              <font color="#990000">*</font></td>
          </tr>
        </table>
        <br>
        <b>Billing Contact Information</b><br>
        <hr size="1" noshade>
        <table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr> 
            <td width="39%">Full name of billing contact</td>
            <td width="61%"> 
              <input type="text" name="billing" value="<?php echo $billing ?>">
              <font color="#990000">*</font> </td>
          </tr>
          <tr> 
            <td width="39%">Organization name</td>
            <td width="61%"> 
              <input type="text" name="b_org" value="<?php echo $b_org ?>">
              <font color="#990000">*</font> </td>
          </tr>
          <tr> 
            <td width="39%">Address 1</td>
            <td width="61%"> 
              <input type="text" name="b_address1" value="<?php echo $b_address1 ?>" size="30">
              <font color="#990000">*</font></td>
          </tr>
          <tr> 
            <td width="39%">Address 2</td>
            <td width="61%"> 
              <input type="text" name="b_address2" value="<?php echo $b_address2 ?>" size="30">
              <font color="#990000">*</font></td>
          </tr>
          <tr> 
            <td width="39%">Address 3</td>
            <td width="61%"> 
              <input type="text" name="b_address3" value="<?php echo $b_address3 ?>" size="30">
              <font color="#990000">*</font></td>
          </tr>
          <tr> 
            <td width="39%">City</td>
            <td width="61%"> 
              <input type="text" name="b_city" value="<?php echo $b_city ?>">
              <font color="#990000">*</font></td>
          </tr>
          <tr> 
            <td width="39%">Province/State</td>
            <td width="61%"> 
              <input type="text" name="b_province" value="<?php echo $b_province ?>">
              <font color="#990000">*</font></td>
          </tr>
          <tr> 
            <td width="39%">Country/Region</td>
            <td width="61%"> 
              <select name="b_country">
<?php
	reset($countries);
	while(list($key, $val) = each($countries))
	{
		if($key == $b_country)
		{
			echo "<option value=\"" . $key . "\" selected>" . $val . "</option>";
		}else {
			echo "<option value=\"" . $key . "\">" . $val . "</option>";
		}
	}
?>
              </select><font color="#990000">*</font></td>
          </tr>
          <tr> 
            <td width="39%">Postal code</td>
            <td width="61%"> 
              <input type="text" name="b_postalcode" value="<?php echo $b_postalcode ?>">
              <font color="#990000">*</font></td>
          </tr>
          <tr> 
            <td width="39%">Telephone(eg:+1.4156656387)</td>
            <td width="61%"> 
              <input type="text" name="b_telephone" value="<?php echo $b_telephone ?>">
              <font color="#990000">*</font></td>
          </tr>
          <tr> 
            <td width="39%">Fax(eg:+1.4156657168)</td>
            <td width="61%"> 
              <input type="text" name="b_fax" value="<?php echo $b_fax ?>">
              <font color="#990000">*</font></td>
          </tr>
          <tr> 
            <td width="39%">E-mail</td>
            <td width="61%"> 
              <input type="text" name="b_email" value="<?php echo $b_email ?>" size="30">
              <font color="#990000">*</font></td>
          </tr>
          <tr> 
            <td width="39%">&nbsp;</td>
            <td width="61%">&nbsp;</td>
          </tr>
          <tr>
            <td width="39%">&nbsp;</td>
            <td width="61%">
              <input type="submit" name="Submit" value="Modify domain contact">
            </td>
          </tr>
        </table>
        <br>
      </form>
      
    </td>
  </tr>
</table>
                  <p>&nbsp;</p>