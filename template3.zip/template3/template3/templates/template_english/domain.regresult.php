<?php
showTitle("Registration result");
?>
                  <br>
                  
<table width="95%" border="0" cellspacing="0" cellpadding="0" align="center">
   <tr>
     
    <td width="25%" height="25" colspan="2"><b><font color="#990000">Register Successfully!</font></b> Your account has been charged a total of $<?php echo $product_price[$year] ?>.<br>
      <br>
      <table width="90%" border="0" cellspacing="0" cellpadding="0" align="center">
        <tr> 
          <td height="22" bgcolor="#EFEFEF" align="center"><?php echo $domain_name ?></td>
        </tr>
      </table>
    </td>
  </tr>
  <tr> 
    <td > 
      <p><br>
      </p>
      <p><br>
        <b>Note:</b> A failed registration could be a result of network congestion 
        or other technical issues and does not necessarily mean that domain is 
        not available. Check the Whois database for details.<br>
      </p>
    </td>
  </tr>
</table>
                  <p>&nbsp;</p>