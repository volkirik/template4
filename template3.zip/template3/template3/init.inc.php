<?php
session_start();
$conn = connectDB();

$sql = "select * from web_config";
$rs = $conn->Execute($sql);
if(!$rs)
{
	echo $conn->ErrorMsg();
	die();
}

/**
 * Skin Define
 */
define("CURRENT_SKIN", $rs->fields[0]);

/**
 * Website Base Define
 */
define("WEBSITE_LANGUAGE", $rs->fields[1]);
define("TITLE", $rs->fields[2]);
define("COPYRIGHT", $rs->fields[3]);
define("PAGE_SIZE", $rs->fields[4]);

/**
 * Website Control
 */
define("SYSTEM_STATUS", $rs->fields[5]);

/**
 * OnlineNIC API Setting
 */
define("CUSTOMER_ID", $rs->fields[7]);
define("PASSWORD", $rs->fields[8]);
define("REG_HOST", $rs->fields[9]);
define("REG_PORT", $rs->fields[10]);

/**
 * Other setting
 */
define("RELA_DIR", $rs->fields[11]);
define("DOM_UPG_HOST", $rs->fields[12]);
define("DOM_UPG_PORT", $rs->fields[13]);
define("DOM_UPG_URL", $rs->fields[14]);
define("SUPPORT_EMAIL", $rs->fields[15]);

$rs->close();

include(ROOT_DIR . "resource/language_" . WEBSITE_LANGUAGE . ".inc.php");
?>