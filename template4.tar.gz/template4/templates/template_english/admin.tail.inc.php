<?php
 global $smarty;
 
 $smarty->assign ('copyright', COPYRIGHT);

?>