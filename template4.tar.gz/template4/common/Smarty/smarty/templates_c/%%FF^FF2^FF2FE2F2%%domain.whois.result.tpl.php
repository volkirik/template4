<?php /* Smarty version 2.6.7, created on 2005-09-08 18:42:36
         compiled from default/domain.whois.result.tpl */ ?>
<table width="95%" border="0" cellspacing="0" cellpadding="0" align="center">
 <tr> 
    <td>
	  <pre><?php echo $this->_tpl_vars['whois_result']; ?>
</pre>
    </td>
  </tr>
</table>