<?php /* Smarty version 2.6.7, created on 2005-09-09 22:32:15
         compiled from default/admin.domainsync.result.tpl */ ?>
                  <br>
<table width="95%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr> 
    <td align=center>
	    <?php echo $this->_tpl_vars['update_result']; ?>

	</td>
  </tr>
  <tr> <td>&nbsp;</td> </tr>
  <tr>
    <td align="center">
        <form action=<?php echo $this->_tpl_vars['php_self']; ?>
  method=post>
            <input type=submit name=submit value=Back>
        </form>
    </td>
  </tr>
</table>
                  <p>&nbsp;</p>