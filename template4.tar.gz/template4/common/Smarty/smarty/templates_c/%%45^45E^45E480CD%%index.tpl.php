<?php /* Smarty version 2.6.7, created on 2005-02-05 00:47:15
         compiled from index.tpl */ ?>
<table border="0" cellspacing="0" cellpadding="0">
  <tbody>
    <tr>
      <td class="head" colspan="2"><?php echo $this->_tpl_vars['formname']; ?>
</td>
    </tr>
    <tr>
      <td class="txt">Name  </td>
      <td class="frm"> <input class="asd" type="text" name="name" value="<?php echo $this->_tpl_vars['name']; ?>
" size=25> </td>
    </tr>
    <tr>
      <td class=txt>Password  </td>
      <td class="frm"> <input class="asd" type="password" name="pass" size=25> </td>
    </tr>
    <tr>
      <td class="sub" colspan="2"> <input class="asd" type="submit" name="submit" value="<?php echo $this->_tpl_vars['subval']; ?>
"> </td>
    </tr>	
  </tbody>
</table>
<br>






</body>
</html>