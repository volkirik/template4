<?php /* Smarty version 2.6.7, created on 2005-11-16 19:08:56
         compiled from simpleGreen/member.signup.successful.tpl */ ?>
<table width="95%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr> 
    <td > 
      <p><font color="#FF0000"><b><i><font size="3">Sign up successfully</font></i></b><br>
        <br>
        </font>Your username is: <?php echo $this->_tpl_vars['member_name']; ?>
<br>
        Your password is: <?php echo $this->_tpl_vars['member_password1']; ?>
<br>
        <br>
        Please write these down in a safe place and please do not give your password to anyone.<br>
        <br>
        To continue using the system, please <a href="<?php echo $this->_tpl_vars['member_login']; ?>
">login</a> 
        now. </p>
      </td>
  </tr>
</table>
                  <p>&nbsp;</p>