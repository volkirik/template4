<?php /* Smarty version 2.6.7, created on 2005-10-27 13:39:16
         compiled from default/system.error.tpl */ ?>
<p><br>
  
</p><p>&nbsp;</p><table width="80%" border="0" cellspacing="0" cellpadding="0" align="center" style="border:solid 1px #878DC7;padding:5px">
  <tr bgcolor="#EFEFEF"> 
    <td height="100" align="center" bgcolor="#F2F7F9"><b><?php echo $this->_tpl_vars['content_message']; ?>
</b></td>
  </tr>
</table>
<p>&nbsp;</p>