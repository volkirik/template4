<?php
	//begin get u_OrderID(u_OrderID is a random)
	$seedarray =microtime();
	$seedstr =split(" ",$seedarray,5);
	$seed =$seedstr[0]*10000;
	srand($seed);
	$random =rand(0,1000);
	$u_OrderID=$random;
	//end
	$password=md5("654123");//password
	$u_UserID="135610";//test customer id
	$u_Action=1;//it means the step1 of register 
	$u_DateTime=Date("Y-m-d H:i");
	$u_Url="http://218.5.81.149/Interface/ssl_demo/reg_step2.php";//the url to receive from 218.5.81.149/Interface/ssl_interface.php
	$extra_str="product_regist_step1";
	$u_Checksum=md5($u_Action.$u_UserID.$u_OrderID.$u_DateTime.$u_Url.$password.$extra_str);
?>
<html>
<head>
<title>ssl</title>
</head>
<body>
<form action="http://218.5.81.149/Interface/ssl_interface.php" method="post">
<h3>geotrust</h3>
<table>
<tr>
<td>product</td>
<td>
<select id="ProductCode" name="ProductCode">
<option value="QuickSSLPremium">QuickSSL   Premium</option>
<option value="RapidSSL"  selected="selected">RapidSSL</option>
</select>
</td>
<td>period</td>
<td><input type="text" name="ValidityPeriod" value="12"></td>
</tr>
<tr>
<td colspan=2>csr</td>
<td colspan=2><textarea rows="6" name="CSR" cols="60" class="r_textarea"></textarea></td>
</tr>
</table>
<input type="hidden" name="u_Url" value="<?=$u_Url ?>">
<input type="hidden" name="u_Action" id="u_Action" value="<?=$u_Action ?>">
<input type="hidden" name="u_UserID" value="<?=$u_UserID ?>">
<input type="hidden" name="u_OrderID" value="<?=$u_OrderID ?>">
<input type="hidden" name="u_Datetime" value="<?=$u_DateTime ?>">
<input type="hidden" name="u_Checksum" value="<?=$u_Checksum ?>">
<p><input type="submit" name="sub" value="submit"></p>
</form>
</body>
</html>
