<?php
        //begin get u_OrderID(u_OrderID is a random)
        $seedarray =microtime();
        $seedstr =split(" ",$seedarray,5);
        $seed =$seedstr[0]*10000;
        srand($seed);
        $random =rand(0,10000);
        $u_OrderID=$random;
        //end
        $password=md5("654123");//password
        $u_UserID="135610";//test customer id
        
		$u_Action_reg=5;//it means register 
		$u_Action_renew=6;
        $u_DateTime=Date("Y-m-d H:i");
        $u_Url="http://218.5.81.149/Interface/ssl_TrueBusiness_step2.php";//the url to receive from 218.5.81.149/Interface/ssl_interface.php
        $extra_str_reg="other_product_regist";
		$extra_str_renew="other_product_renew";
        $u_Checksum_reg=md5($u_Action_reg.$u_UserID.$u_OrderID.$u_DateTime.$u_Url.$password.$extra_str_reg);
		$u_Checksum_renew=md5($u_Action_renew.$u_UserID.$u_OrderID.$u_DateTime.$u_Url.$password.$extra_str_renew);
?>
<html>
<head>
<title>ssl</title>
</head>
<body>
<form action="http://218.5.81.149/Interface/ssl_interface.php" method="post">
<h3>geotrust</h3>
<table>
<tr>
<td>product</td>
<td>
<select id="ProductCode" name="ProductCode">
<option value="TrueBizID" selected>True BusinessID</option>
<option value="TrueBizID1">True BusinessID Wildcard</option>
</select>
</td>
<td>period</td>
<td><input type="text" name="ValidityPeriod" value="12"></td>
</tr>
<tr>
<td>Initial/Renewal</td>
<td>
<select id="operate_action" name="RenewalIndicator">
<option value="false" selected="selected">Initial Order</option>
<option value="true">Renewal</option>
</select>
</td>
<td>Server Type</td>
<td>
<select name="WebServerType">;110H2
<option value=apachessl>Apache + MOD SSL </option>
<option value=apacheraven>Apache + Raven </option>
<option value=apachessleay>Apache + SSLeay </option>
<option value=c2net>C2Net Stronghold </option>
<option value=-->--- </option>
<option value=-->--- </option>
<option value=Ibmhttp>IBM HTTP</option>
<option value=Iplanet>iPlanet Server 4.1</option>
<option value=Dominogo4625>Lotus Domino Go 4.6.2.51</option>
<option value=Dominogo4626>Lotus Domino Go 4.6.2.6+ </option>
<option value=Domino>Lotus Domino 4.6+ </option>
<option value=iis4>Microsoft IIS 4.0 </option>
<option value=iis5>Microsoft IIS 5.0 </option>
<option value=iis>Microsoft Internet Information Server </option>
<option value=iis5>Microsoft IIS 5.0 </option>
<option value=iis>Microsoft Internet Information Server </option>
<option value=Netscape>Netscape Enterprise/FastTrack </option>
<option value=-->--- </option>
<option value=zeusv3>Zeus v3+ </option>
<option value=Other>Other </option>
<option value=-->-- </option>
<option value=apacheopenssl>Apache + OpenSSL </option>
<option value=apache2>Apache 2 </option>
<option value=apacheapachessl>Apache + ApacheSSL </option>
<option value=cobaltseries>Cobalt Series </option>
<option value=cpanel>Cpanel </option>
<option value=ensim>Ensim </option>
<option value=hsphere>Hsphere </option>
<option value=ipswitch>Ipswitch </option>
<option value=plesk>Plesk </option>
<option value=tomcat>Jakart-Tomcat </option>
<option value=weblogic>Weblogic - all versions</option>
<option value=website>O'Reilly WebSite Professional </option>
<option value=webstar>WebStar </option>
</select>
</td>
</tr>
<tr>
<td>price</td>
<td><?=$price ?></td>
<td colspan="2"></td>
</tr>
<tr>
<td colspan=2>csr</td>
<td colspan=2><textarea rows="6" name="CSR" cols="60" class="r_textarea"><?=$csr ?></textarea></td>
</tr>
</table>
<h3>Administrator</h3>
<table>
<tr>
<td>first name</td>
<td><input type="text" name="a_FirstName" value="chen"></td>
<td>last name</td>
<td><input type="text" name="a_LastName" value="yan"></td>
</tr>
<tr>
<td>telephone</td>
<td><input type="text" name="a_Phone" value="+1.3950160530"></td>
<td>email</td>
<td><input type="text" name="a_Email" value="hahaha@sina.com"></td>
</tr>
<tr>
<td>title</td>
<td><input type"text" name="a_Title" value="ychen"></td>
<td></td><td></td>
</tr>
</table>
<h3>Technical</h3>
<table>
<tr>
<td>first name</td>
<td><input type="text" name="t_FirstName" value="chen"></td>
<td>last name</td>
<td><input type="text" name="t_LastName" value="yan"></td>
</tr>
<tr>
<td>telephone</td>
<td><input type="text" name="t_Phone" value="+1.3950160530"></td>
<td>email</td>
<td><input type="text" name="t_Email" value="hahaha@sina.com"></td>
</tr>
<tr>
<td>title</td>
<td><input type"text" name="t_Title" value="ychen"></td>
<td></td><td></td>
</tr>
</table>
<h3>Organization Info</h3>
<table>
<tr><td>Organization Name</td><td><input type="text" name="OrganizationName" value="organization name"></td></tr>
<tr><td>DUNS</td><td><input type="text" name="DUNS" value=""></td></tr>
<tr><td>FORM_ORG_ADDRESS1</td><td><input type="text" name="o_AddressLine1" value="xia men fu jian"></td></tr>
<tr><td>FORM_ORG_ADDRESS2</td><td><input type="text" name="o_AddressLine2" value="xia men fu jian"></td></tr>
<tr><td>FORM_ORG_ADDRESS3</td><td><input type="text" name="o_AddressLine3" value="xia men fu jian"></td></tr>
<tr><td>City</td><td><input type="text" name="o_City" value="xia men"></td></tr>
<tr><td>State/Province</td><td><input type="text" name="o_Region" value="fu jian"></td></tr>
<tr><td>Zip/PostCode</td><td><input type="text" name="o_PostalCode" value="361104"></td></tr>
<tr>
	<td>Country</td>
	<td><select name="o_Country">
	<option value='AF'>AFGHANISTAN</option>
<option value='AL'>ALBANIA</option>
<option value='BW'>BOTSWANA</option>
<option value='DZ'>ALGERIA</option>
<option value='AS'>AMERICAN SAMOA</option>

<option value='AD'>ANDORRA</option>
<option value='AO'>ANGOLA</option>
<option value='AI'>ANGUILLA</option>
<option value='AQ'>ANTARCTICA</option>
<option value='AG'>ANTIGUA AND BARBUDA</option>
<option value='AR'>ARGENTINA</option>
<option value='AM'>ARMENIA</option>
<option value='AW'>ARUBA</option>
<option value='AU'>AUSTRALIA</option>

<option value='AT'>AUSTRIA</option>
<option value='AZ'>AZERBAIJAN</option>
<option value='BS'>BAHAMAS</option>
<option value='BH'>BAHRAIN</option>
<option value='BD'>BANGLADESH</option>
<option value='BB'>BARBADOS</option>
<option value='BY'>BELARUS</option>
<option value='BE'>BELGIUM</option>
<option value='BZ'>BELIZE</option>

<option value='BJ'>BENIN</option>
<option value='BM'>BERMUDA</option>
<option value='BT'>BHUTAN</option>
<option value='BO'>BOLIVIA</option>
<option value='BA'>BOSNIA AND HERZEGOV</option>
<option value='BV'>BOUVET ISLAND</option>
<option value='BR'>BRAZIL</option>
<option value='IO'>BRITISH INDIAN OCEA</option>
<option value='BN'>BRUNEI DARUSSALAM</option>

<option value='BG'>BULGARIA</option>
<option value='BF'>BURKINA FASO</option>
<option value='BI'>BURUNDI</option>
<option value='KH'>CAMBODIA</option>
<option value='CM'>CAMEROON</option>
<option value='CA'>CANADA</option>
<option value='CV'>CAPE VERDE</option>
<option value='KY'>CAYMAN ISLANDS</option>
<option value='CF'>CENTRAL AFRICAN REP</option>

<option value='TD'>CHAD</option>
<option value='CL'>CHILE</option>
<option value='CN'>CHINA</option>
<option value='CX'>CHRISTMAS ISLAND</option>
<option value='CC'>COCOS (KEELING) ISL</option>
<option value='CO'>COLOMBIA</option>
<option value='KM'>COMOROS</option>
<option value='CG'>CONGO</option>
<option value='CD'>CONGO, THE DEMOCRAT</option>

<option value='CK'>COOK ISLANDS</option>
<option value='CR'>COSTA RICA</option>
<option value='CI'>C?TE D'IVOIRE</option>
<option value='HR'>CROATIA</option>
<option value='CU'>CUBA</option>
<option value='CY'>CYPRUS</option>
<option value='CZ'>CZECH REPUBLIC</option>
<option value='DK'>DENMARK</option>
<option value='DJ'>DJIBOUTI</option>

<option value='DM'>DOMINICA</option>
<option value='DO'>DOMINICAN REPUBLIC</option>
<option value='TP'>EAST TIMOR</option>
<option value='EC'>ECUADOR</option>
<option value='EG'>EGYPT</option>
<option value='SV'>EL SALVADOR</option>
<option value='GQ'>EQUATORIAL GUINEA</option>
<option value='ER'>ERITREA</option>
<option value='EE'>ESTONIA</option>

<option value='ET'>ETHIOPIA</option>
<option value='FK'>FALKLAND ISLANDS (M</option>
		<option value='FO'>FAROE ISLANDS</option>
		<option value='FJ'>FIJI</option>
		<option value='FI'>FINLAND</option>
		<option value='FR'>FRANCE</option>
		<option value='GF'>FRENCH GUIANA</option>

		<option value='PF'>FRENCH POLYNESIA</option>
		<option value='TF'>FRENCH SOUTHERN TER</option>
		<option value='GA'>GABON</option>
		<option value='GM'>GAMBIA</option>
		<option value='GE'>GEORGIA</option>
		<option value='DE'>GERMANY</option>

		<option value='GH'>GHANA</option>
		<option value='GI'>GIBRALTAR</option>
		<option value='GR'>GREECE</option>
		<option value='GL'>GREENLAND</option>
		<option value='GD'>GRENADA</option>
		<option value='GP'>GUADELOUPE</option>

		<option value='GU'>GUAM</option>
		<option value='GT'>GUATEMALA</option>
		<option value='GN'>GUINEA</option>
		<option value='GW'>GUINEA-BISSAU</option>
<option value='GY'>GUYANA</option>
<option value='HT'>HAITI</option>
<option value='HM'>HEARD ISLAND AND MC</option>

<option value='VA'>HOLY SEE (VATICAN C</option>
		<option value='HN'>HONDURAS</option>
		<option value='HK'>HONG KONG</option>
		<option value='HU'>HUNGARY</option>
		<option value='IS'>ICELAND</option>
		<option value='IN'>INDIA</option>

		<option value='ID'>INDONESIA</option>
		<option value='IR'>IRAN, ISLAMIC REPUB</option>
		<option value='IQ'>IRAQ</option>
		<option value='IE'>IRELAND</option>
		<option value='IL'>ISRAEL</option>
		<option value='IT'>ITALY</option>

		<option value='JM'>JAMAICA</option>
		<option value='JP'>JAPAN</option>
		<option value='JO'>JORDAN</option>
		<option value='KZ'>KAZAKSTAN</option>
		<option value='KE'>KENYA</option>
		<option value='KI'>KIRIBATI</option>

		<option value='KP'>KOREA, DEMOCRATIC P</option>
		<option value='KR'>KOREA, REPUBLIC OF</option>
		<option value='KW'>KUWAIT</option>
		<option value='KG'>KYRGYZSTAN</option>
<option value='LA'>LAO PEOPLE'S DEMOCR</option>
<option value='LV'>LATVIA</option>
<option value='LB'>LEBANON</option>

<option value='LS'>LESOTHO</option>
<option value='LR'>LIBERIA</option>
<option value='LY'>LIBYAN ARAB JAMAHIR</option>
<option value='LI'>LIECHTENSTEIN</option>
<option value='LT'>LITHUANIA</option>
<option value='LU'>LUXEMBOURG</option>
<option value='MO'>MACAU</option>
<option value='MK'>MACEDONIA, THE FORM</option>
<option value='MG'>MADAGASCAR</option>

<option value='MW'>MALAWI</option>
<option value='MY'>MALAYSIA</option>
<option value='MV'>MALDIVES</option>
<option value='ML'>MALI</option>
<option value='MT'>MALTA</option>
<option value='MH'>MARSHALL ISLANDS</option>
<option value='MQ'>MARTINIQUE</option>
<option value='MR'>MAURITANIA</option>
<option value='MU'>MAURITIUS</option>

<option value='YT'>MAYOTTE</option>
<option value='MX'>MEXICO</option>
<option value='FM'>MICRONESIA, FEDERAT</option>
<option value='MD'>MOLDOVA, REPUBLIC O</option>
<option value='MC'>MONACO</option>
<option value='MN'>MONGOLIA</option>
<option value='MS'>MONTSERRAT</option>
<option value='MA'>MOROCCO</option>
<option value='MZ'>MOZAMBIQUE</option>

<option value='MM'>MYANMAR</option>
<option value='NA'>NAMIBIA</option>
<option value='NR'>NAURU</option>
<option value='NP'>NEPAL</option>
<option value='NL'>NETHERLANDS</option>
<option value='AN'>NETHERLANDS ANTILLE</option>
<option value='NC'>NEW CALEDONIA</option>
<option value='NZ'>NEW ZEALAND</option>
<option value='NI'>NICARAGUA</option>

<option value='NE'>NIGER</option>
<option value='NG'>NIGERIA</option>
<option value='NU'>NIUE</option>
<option value='NF'>NORFOLK ISLAND</option>
<option value='MP'>NORTHERN MARIANA IS</option>
<option value='NO'>NORWAY</option>
<option value='OM'>OMAN</option>
<option value='PK'>PAKISTAN</option>
<option value='PW'>PALAU</option>

<option value='PS'>PALESTINIAN TERRITO</option>
<option value='PA'>PANAMA</option>
<option value='PG'>PAPUA NEW GUINEA</option>
<option value='PY'>PARAGUAY</option>
<option value='PE'>PERU</option>
<option value='PH'>PHILIPPINES</option>
<option value='PN'>PITCAIRN</option>
<option value='PL'>POLAND</option>
<option value='PT'>PORTUGAL</option>

<option value='PR'>PUERTO RICO</option>
<option value='QA'>QATAR</option>
<option value='RE'>R��|UNION</option>
<option value='RO'>ROMANIA</option>
<option value='RU'>RUSSIAN FEDERATION</option>
<option value='RW'>RWANDA</option>
<option value='SH'>SAINT HELENA</option>
<option value='KN'>SAINT KITTS AND NEV</option>
<option value='LC'>SAINT LUCIA</option>

<option value='PM'>SAINT PIERRE AND MI</option>
<option value='VC'>SAINT VINCENT AND T</option>
<option value='WS'>SAMOA</option>
<option value='SM'>SAN MARINO</option>
<option value='ST'>SAO TOME AND PRINCI</option>
<option value='SA'>SAUDI ARABIA</option>
<option value='SN'>SENEGAL</option>
<option value='SC'>SEYCHELLES</option>
<option value='SL'>SIERRA LEONE</option>

<option value='SG'>SINGAPORE</option>
<option value='SK'>SLOVAKIA</option>
<option value='SI'>SLOVENIA</option>
<option value='SB'>SOLOMON ISLANDS</option>
<option value='SO'>SOMALIA</option>
<option value='ZA'>SOUTH AFRICA</option>
<option value='GS'>SOUTH GEORGIA AND T</option>
<option value='ES'>SPAIN</option>
<option value='LK'>SRI LANKA</option>

<option value='SD'>SUDAN</option>
<option value='SR'>SURINAME</option>
<option value='SJ'>SVALBARD AND JAN MA</option>
<option value='SZ'>SWAZILAND</option>
<option value='SE'>SWEDEN</option>
<option value='CH'>SWITZERLAND</option>
<option value='SY'>SYRIAN ARAB REPUBLI</option>
<option value='TW'>CHINAESE TAIBEI</option>
<option value='TJ'>TAJIKISTAN</option>

<option value='TZ'>TANZANIA, UNITED RE</option>
<option value='TH'>THAILAND</option>
<option value='TG'>TOGO</option>
<option value='TK'>TOKELAU</option>
<option value='TO'>TONGA</option>
<option value='TT'>TRINIDAD AND TOBAGO</option>
<option value='TN'>TUNISIA</option>
<option value='TR'>TURKEY</option>
<option value='TM'>TURKMENISTAN</option>

<option value='TC'>TURKS AND CAICOS IS</option>
<option value='UA'>UKRAINE</option>
<option value='AE'>UNITED ARAB EMIRATE</option>
<option value='UM'>UNITED STATES MINOR</option>
<option value='UY'>URUGUAY</option>
<option value='UZ'>UZBEKISTAN</option>
<option value='VU'>VANUATU</option>
<option value='VE'>VENEZUELA</option>
<option value='VN'>VIET NAM</option>

<option value='VG'>VIRGIN ISLANDS, BRI</option>
<option value='VI'>VIRGIN ISLANDS, U.S</option>
<option value='WF'>WALLIS AND FUTUNA</option>
<option value='EH'>WESTERN SAHARA</option>
<option value='YE'>YEMEN</option>
<option value='YU'>YUGOSLAVIA</option>
<option value='ZM'>ZAMBIA</option>
<option value='ZW'>ZIMBABWE</option>
</select>
	</td></tr>
<tr><td>Telephone</td><td><input type="text" name="o_Phone" value="+1.4156656387"></td></tr>
<tr><td>Fax</td><td><input type="text" name="o_Fax" value="+1.4156656387"></td></tr>
</table>
<p><input type="checkbox" value="1" name="agreement" checked>agree</p>
<input type="hidden" name="u_Url" value="<?=$u_Url ?>">
<input type="hidden" id="u_Action" name="u_Action" value="<?=$u_Action_reg ?>">
<input type="hidden" name="u_UserID" value="<?=$u_UserID ?>">
<input type="hidden" name="u_OrderID" value="<?=$u_OrderID ?>">
<input type="hidden" name="u_Datetime" value="<?=$u_DateTime ?>">
<input type="hidden" id="u_Checksum" name="u_Checksum" value="<?=$u_Checksum_reg ?>">
<p><input type="submit" name="sub" value="submit"></p>
</form>
</html>
</body>
