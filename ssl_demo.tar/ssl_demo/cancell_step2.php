<?php
	echo "$_POST[r_Result]";
	echo "<p>$_POST[r_Error]</p>";
?>
