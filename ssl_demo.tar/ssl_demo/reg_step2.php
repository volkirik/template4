<?php
if( 0 == $_POST[r_Result]){
	//get param
	$emails=explode("|",$_POST[ApproverEmail]);
	$price=$_POST[Price];
	$productcode=$_POST[ProductCode];
	$csr=$_POST[CSR];
	$period=$_POST[ValidityPeriod];

	//begin get u_OrderID(u_OrderID is a random)
	$seedarray =microtime();
	$seedstr =split(" ",$seedarray,5);
	$seed =$seedstr[0]*10000;
	srand($seed);
	$random =rand(0,1000);
	$u_OrderID=$random;
	//end

	$password=md5("654123");//password
	$u_UserID="135610";//test customer id
	$u_Action=2;//it means the step2 of register
	$u_DateTime=Date("Y-m-d H:i");
	$u_Url="http://218.5.81.149/Interface/ssl_demo/reg_step3.php";//the url to receive form 218.5.81.149/Interface/ssl_interface.php
	$extra_str="product_regist_step2";
	$u_Checksum=md5($u_Action.$u_UserID.$u_OrderID.$u_DateTime.$u_Url.$password.$extra_str);
?>
<form action="http://218.5.81.149/Interface/ssl_interface.php" method="post">
<h3>geotrust</h3>
<table>
<tr>
<td>product</td>
<td><input type="text" name="ProductCode" value="<?=$productcode ?>"></td>
<td>period</td>
<td><input type="text" name="ValidityPeriod" value="<?=$period ?>"></td>
</tr>
<tr>
<td>Server Type</td>
<td>
<select name="WebServerType">;110H2
<option value=apachessl>Apache + MOD SSL </option>
<option value=apacheraven>Apache + Raven </option>
<option value=apachessleay>Apache + SSLeay </option>
<option value=c2net>C2Net Stronghold </option>
<option value=-->--- </option>
<option value=-->--- </option>
<option value=Ibmhttp>IBM HTTP</option>
<option value=Iplanet>iPlanet Server 4.1</option>
<option value=Dominogo4625>Lotus Domino Go 4.6.2.51</option>
<option value=Dominogo4626>Lotus Domino Go 4.6.2.6+ </option>
<option value=Domino>Lotus Domino 4.6+ </option>
<option value=iis4>Microsoft IIS 4.0 </option>
<option value=iis5>Microsoft IIS 5.0 </option>
<option value=iis>Microsoft Internet Information Server </option>
<option value=Netscape>Netscape Enterprise/FastTrack </option>
<option value=-->--- </option>
<option value=zeusv3>Zeus v3+ </option>
<option value=Other>Other </option>
<option value=-->-- </option>
<option value=apacheopenssl>Apache + OpenSSL </option>
<option value=apache2>Apache 2 </option>
<option value=apacheapachessl>Apache + ApacheSSL </option>
<option value=cobaltseries>Cobalt Series </option>
<option value=cpanel>Cpanel </option>
<option value=ensim>Ensim </option>
<option value=hsphere>Hsphere </option>
<option value=ipswitch>Ipswitch </option>
<option value=plesk>Plesk </option>
<option value=tomcat>Jakart-Tomcat </option>
<option value=weblogic>Weblogic - all versions</option>
<option value=website>O'Reilly WebSite Professional </option>
<option value=webstar>WebStar </option>
</select>
</td>
<td>price</td>
<td><?=$price ?></td>
<td colspan="2"></td>
</tr>
<tr>
<td colspan=2>csr</td>
<td colspan=2><textarea rows="6" name="CSR" cols="60" class="r_textarea"><?=$csr ?></textarea></td>
</tr>
</table>
<h3>Administrator</h3>
<table>
<tr>
<td>first name</td>
<td><input type="text" name="a_FirstName" value="chen"></td>
<td>last name</td>
<td><input type="text" name="a_LastName" value="yan"></td>
</tr>
<tr>
<td>telephone</td>
<td><input type="text" name="a_Phone" value="+1.3950160530"></td>
<td>email</td>
<td><input type="text" name="a_Email" value="chenyan2@onlinenic.com"></td>
</tr>
<tr>
<td>title</td>
<td><input type"text" name="a_Title" value="ychen"></td>
<td></td><td></td>
</tr>
</table>
<h3>Technical</h3>
<table>
<tr>
<td>first name</td>
<td><input type="text" name="t_FirstName" value="chen"></td>
<td>last name</td>
<td><input type="text" name="t_LastName" value="yan"></td>
</tr>
<tr>
<td>telephone</td>
<td><input type="text" name="t_Phone" value="+1.3950160530"></td>
<td>email</td>
<td><input type="text" name="t_Email" value="chenyan2@onlinenic.com"></td>
</tr>
<tr>
<td>title</td>
<td><input type"text" name="t_Title" value="ychen"></td>
<td></td><td></td>
</tr>
<tr>
<td>your email to receive confirm email</td>
<td>
<?php
echo "<select name='ApproverEmail'>";
for($i=0;$i<sizeof($emails);$i++)
        echo "<option value='$emails[$i]'>$emails[$i]</option>";
echo "</select>";
?>
</td>
<td colspan="2"></td>
</tr>
</table>
<p><input type="checkbox" value="1" name="agreement" checked>agree</p>
<input type="hidden" name="u_Url" value="<?=$u_Url ?>">
<input type="hidden" name="u_Action" value="<?=$u_Action ?>">
<input type="hidden" name="u_UserID" value="<?=$u_UserID ?>">
<input type="hidden" name="u_OrderID" value="<?=$u_OrderID ?>">
<input type="hidden" name="u_Datetime" value="<?=$u_DateTime ?>">
<input type="hidden" name="u_Checksum" value="<?=$u_Checksum ?>">
<p><input type="submit" name="sub" value="submit"></p>
</form>
<?php
}
else{
	echo "$_POST[r_Result]";
	echo "<p>$_POST[r_Error]</p>";
}
?>
