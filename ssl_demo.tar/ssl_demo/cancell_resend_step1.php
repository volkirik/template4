<?php
	//get u_OrderID
	$seedarray =microtime();
        $seedstr =split(" ",$seedarray,5);
        $seed =$seedstr[0]*10000;
        srand($seed);
        $random =rand(0,1000);
        $u_OrderID=$random;
        
	$password=md5("654123");
        $u_UserID="135610";
        $u_Action_resend=8;//it means resend email
	$u_Action_cancell=7;//it means cancell order
        $u_DateTime=Date("Y-m-d H:i");
        $u_Url_resend="http://218.5.81.149/Interface/ssl_demo/resend_step2.php";//the url to receive from 218.5.81.149/Interface/ssl_interface.php
	$u_Url_cancell="http://218.5.81.149/Interface/ssl_demo/cancell_step2.php";//the url to receive from 218.5.81.149/Interface/ssl_interface.php
        $extra_str_resend="product_resendemail";
	$extra_str_cancell="product_cancelorder";
        $u_Checksum_resend=md5($u_Action_resend.$u_UserID.$u_OrderID.$u_DateTime.$u_Url_resend.$password.$extra_str_resend);
	$u_Checksum_cancell=md5($u_Action_cancell.$u_UserID.$u_OrderID.$u_DateTime.$u_Url_cancell.$password.$extra_str_cancell);	
?>
<h1>geotrust</h1>
<h3>cancell ssl</h3>
<form name = "form1" action ="http://218.5.81.149/Interface/ssl_interface.php" method="post">
<table>
<tr>
<td>please input your order to cancell</td>
<td><input type="text" name="u_GlobalID"></td>
</tr>
</table>
<p><input type="checkbox" value="1" name="agreement" checked>agree</p>
<input type="hidden" name="u_Url" value="<?=$u_Url_cancell ?>">
<input type="hidden" name="u_Action" value="<?=$u_Action_cancell ?>">
<input type="hidden" name="u_UserID" value="<?=$u_UserID ?>">
<input type="hidden" name="u_OrderID" value="<?=$u_OrderID ?>">
<input type="hidden" name="u_Datetime" value="<?=$u_DateTime ?>">
<input type="hidden" name="u_Checksum" value="<?=$u_Checksum_cancell ?>">
<p><input type="submit" name="sub" value="cancell"></p>
</form>
<br/>
<hr/>
<br/>
<h3>resend email</h3>
<form name = "form1" action ="218.5.81.149/Interface/ssl_interface.php" method="post">
<table>
<tr>
<td>please input your order to resend email</td>
<td><input type="text" name="u_GlobalID"></td>
</tr>
</table>
<input type="hidden" name="u_Url" value="<?=$u_Url_resend ?>">
<input type="hidden" name="u_Action" value="<?=$u_Action_resend ?>">
<input type="hidden" name="u_UserID" value="<?=$u_UserID ?>">
<input type="hidden" name="u_OrderID" value="<?=$u_OrderID ?>">
<input type="hidden" name="u_Datetime" value="<?=$u_DateTime ?>">
<input type="hidden" name="u_Checksum" value="<?=$u_Checksum_resend ?>">
<p><input type="submit" name="sub" value="resend email"></p>
</form>
	
